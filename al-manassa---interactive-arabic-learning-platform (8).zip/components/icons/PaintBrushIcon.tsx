
import React from 'react';

export const PaintBrushIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.2 15.75v3.375c0 1.24 1.01 2.25 2.25 2.25h11.1c1.24 0 2.25-1.01 2.25-2.25v-3.375M4.2 15.75h15.6M4.2 15.75 3 13.5v-3c0-1.24 1.01-2.25 2.25-2.25h13.5c1.24 0 2.25 1.01 2.25 2.25v3l-1.2 2.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.375 12v2.25m11.25-2.25v2.25M12 12v2.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="m15 6-3-3-3 3" />
  </svg>
);
