
import React from 'react';

export const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.868 2.884c.321-.662 1.215-.662 1.536 0l1.681 3.462a1 1 0 00.951.692h3.632c.712 0 1.008.972.454 1.454l-2.938 2.14a1 1 0 00-.364 1.118l1.681 3.462c.321.662-.525 1.48-1.12 1.026l-2.938-2.14a1 1 0 00-1.175 0l-2.938 2.14c-.595.454-1.442-.364-1.12-1.026l1.681-3.462a1 1 0 00-.364-1.118L2.05 8.492c-.554-.482-.258-1.454.454-1.454h3.632a1 1 0 00.951-.692l1.681-3.462z" clipRule="evenodd" />
  </svg>
);
