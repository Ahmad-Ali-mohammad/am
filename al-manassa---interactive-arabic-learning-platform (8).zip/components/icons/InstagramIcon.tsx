import React from 'react';

export const InstagramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    {...props}
  >
    <defs>
      <linearGradient id="ig-grad" x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#feda75" />
        <stop offset="25%" stopColor="#fa7e1e" />
        <stop offset="50%" stopColor="#d62976" />
        <stop offset="75%" stopColor="#962fbf" />
        <stop offset="100%" stopColor="#4f5bd5" />
      </linearGradient>
    </defs>
    <path
      fill="url(#ig-grad)"
      d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.07-1.645-.07-4.85s.012-3.584.07-4.85c.149-3.225 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163z"
    />
    <path
      fill="#fff"
      d="M12 7.056c-2.73 0-4.944 2.214-4.944 4.944s2.214 4.944 4.944 4.944 4.944-2.214 4.944-4.944S14.73 7.056 12 7.056zm0 8.088c-1.737 0-3.144-1.407-3.144-3.144s1.407-3.144 3.144-3.144c1.737 0 3.144 1.407 3.144 3.144s-1.407 3.144-3.144 3.144zM16.949 5.856a1.2 1.2 0 11-2.4 0 1.2 1.2 0 012.4 0z"
    />
  </svg>
);