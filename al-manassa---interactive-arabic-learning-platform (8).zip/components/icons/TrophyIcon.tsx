
import React from 'react';

export const TrophyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9a9.75 9.75 0 0 1-4.874-1.971 2.25 2.25 0 0 1-1.28-2.053V8.784a2.25 2.25 0 0 1 1.28-2.053A9.753 9.753 0 0 1 7.5 5.25h9a9.753 9.753 0 0 1 4.874 1.458A2.25 2.25 0 0 1 22.5 8.784v5.942a2.25 2.25 0 0 1-1.28 2.053A9.75 9.75 0 0 1 16.5 18.75Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75v-3.75m0 0a2.25 2.25 0 0 0-4.5 0m4.5 0a2.25 2.25 0 0 1 4.5 0" />
    </svg>
);
