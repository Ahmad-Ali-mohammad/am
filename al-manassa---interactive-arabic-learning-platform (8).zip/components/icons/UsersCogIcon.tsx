
import React from 'react';

export const UsersCogIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-2.438c.155-.155.295-.312.433-.472a11.95 11.95 0 0 0-2.09-1.923 9.38 9.38 0 0 0-2.625-.372 9.337 9.337 0 0 0-4.12 2.438c-.155.155-.295.312-.433.472M15 19.128v-3.375c0-.621-.504-1.125-1.125-1.125H6.375c-.621 0-1.125.504-1.125 1.125v3.375m0 0a3 3 0 0 1-3-3V9.563a3 3 0 0 1 1.659-2.69l4.5-2.25a3 3 0 0 1 3.682 0l4.5 2.25A3 3 0 0 1 18 9.563v6.563a3 3 0 0 1-3 3M10.5 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 13.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
  </svg>
);
