
import React from 'react';

export const WrenchScrewdriverIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.471-2.471a.563.563 0 0 1 .8 0l2.471 2.471m-5.742 0L5.539 9.32a2.652 2.652 0 0 0-3.75 0L1.5 12l5.877 5.877a2.652 2.652 0 0 0 3.75 0L15.17 11.42m-5.742 0a.563.563 0 0 1 .8 0l2.471 2.471" />
  </svg>
);
