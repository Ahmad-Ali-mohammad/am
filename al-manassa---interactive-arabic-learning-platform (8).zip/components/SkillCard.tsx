
import React from 'react';
import { SkillCourse } from '../types';
import { PlayCircleIcon } from './icons/PlayCircleIcon';

interface SkillCardProps {
  skill: SkillCourse;
}

const SkillCard: React.FC<SkillCardProps> = ({ skill }) => {
  return (
    <a 
      href={skill.link} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="block group bg-white rounded-3xl shadow-lg hover:shadow-2xl overflow-hidden transform hover:-translate-y-3 transition-all duration-500 border border-slate-100"
    >
      <div className="relative h-56 overflow-hidden">
        <img 
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
            src={skill.imageUrl} 
            alt={skill.title} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 scale-50 group-hover:scale-100">
          <div className="bg-white/20 backdrop-blur-md p-4 rounded-full border border-white/30">
            <PlayCircleIcon className="w-12 h-12 text-white" />
          </div>
        </div>
        
        {/* Platform Badge */}
        <div className="absolute top-4 right-4">
            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg ${
                skill.platform === 'YouTube' ? 'bg-red-600 text-white' : 'bg-primary-600 text-white'
            }`}>
                {skill.platform === 'YouTube' ? 'يوتيوب' : 'المنصّة'}
            </span>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 rounded-full bg-primary-500"></span>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{skill.category}</span>
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2 min-h-[3.5rem] leading-snug">
            {skill.title}
        </h3>
        <p className="text-slate-500 text-sm mb-6 line-clamp-3 leading-relaxed">
            {skill.description}
        </p>
        
        <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                بدراسة ذاتية
            </span>
            <span className="text-primary-600 text-sm font-black flex items-center gap-1 group-hover:gap-2 transition-all">
                ابدأ المسار
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            </span>
        </div>
      </div>
    </a>
  );
};

export default SkillCard;
