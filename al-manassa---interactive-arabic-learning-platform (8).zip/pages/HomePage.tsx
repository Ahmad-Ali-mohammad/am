
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseCard from '../components/CourseCard';
import { MOCK_COURSES } from '../constants';
import { BookOpenIcon } from '../components/icons/BookOpenIcon';
import { AcademicCapIcon } from '../components/icons/AcademicCapIcon';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { CodeBracketIcon } from '../components/icons/CodeBracketIcon';
import { BriefcaseIcon } from '../components/icons/BriefcaseIcon';
import { PaintBrushIcon } from '../components/icons/PaintBrushIcon';
import { BeakerIcon } from '../components/icons/BeakerIcon';
import { CurrencyDollarIcon } from '../components/icons/CurrencyDollarIcon';


const AnimatedStat = ({ finalValue, label }: { finalValue: number, label: string }) => {
    const [count, setCount] = useState(0);
    const targetRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    let start = 0;
                    const duration = 2000;
                    const end = finalValue;
                    if (start === end) return;

                    let startTimestamp: number | null = null;
                    const step = (timestamp: number) => {
                        if (!startTimestamp) startTimestamp = timestamp;
                        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                        setCount(Math.floor(progress * (end - start) + start));
                        if (progress < 1) {
                            window.requestAnimationFrame(step);
                        }
                    };
                    window.requestAnimationFrame(step);
                    observer.unobserve(targetRef.current!);
                }
            },
            { threshold: 0.5 }
        );

        if (targetRef.current) {
            observer.observe(targetRef.current);
        }

        return () => {
            if (targetRef.current) {
                observer.unobserve(targetRef.current);
            }
        };
    }, [finalValue]);

    return (
        <div ref={targetRef} className="text-center">
            <p className="text-4xl md:text-5xl font-bold text-primary-600">
                +{count.toLocaleString('ar-EG')}
            </p>
            <p className="text-lg text-gray-600 mt-2">{label}</p>
        </div>
    );
};


const HomePage: React.FC = () => {
    
  const categories = [
    { icon: <CodeBracketIcon className="h-10 w-10 text-primary-500" />, title: 'البرمجة', courses: 250},
    { icon: <BriefcaseIcon className="h-10 w-10 text-primary-500" />, title: 'أعمال', courses: 150},
    { icon: <PaintBrushIcon className="h-10 w-10 text-primary-500" />, title: 'فنون وتصميم', courses: 95},
    { icon: <BeakerIcon className="h-10 w-10 text-primary-500" />, title: 'علوم', courses: 180},
    { icon: <BookOpenIcon className="h-10 w-10 text-primary-500" />, title: 'تاريخ الفن', courses: 50},
    { icon: <CurrencyDollarIcon className="h-10 w-10 text-primary-500" />, title: 'المالية', courses: 75},
  ];

  const testimonials = [
      { name: 'علياء منصور', role: 'طالبة جامعية', quote: 'المنصة غيرت طريقة دراستي تمامًا. المحتوى عالي الجودة والمدربون خبراء بمعنى الكلمة. أنصح بها بشدة!', avatarUrl: 'https://picsum.photos/seed/testimonial1/100/100' },
      { name: 'خالد الغامدي', role: 'مهندس برمجيات', quote: 'كمحترف، أبحث دائمًا عن تطوير مهاراتي. الدورات المتقدمة في المنصة ساعدتني على البقاء في طليعة التكنولوجيا.', avatarUrl: 'https://picsum.photos/seed/testimonial2/100/100' },
      { name: 'سارة عبدالله', role: 'مصممة جرافيك', quote: 'وجدت الإلهام والمعرفة في دورات الفنون. المجتمع التفاعلي والمدربون كانوا داعمين جدًا في رحلتي الإبداعية.', avatarUrl: 'https://picsum.photos/seed/testimonial3/100/100' },
  ];
  
  const partners = [
    { name: 'جامعة الملك سعود', logoUrl: 'https://picsum.photos/seed/ksu/200/80' },
    { name: 'جامعة القاهرة', logoUrl: 'https://picsum.photos/seed/cairo/200/80' },
    { name: 'الجامعة الأمريكية في بيروت', logoUrl: 'https://picsum.photos/seed/aub/200/80' },
    { name: 'معهد ماساتشوستس للتكنولوجيا (عربي)', logoUrl: 'https://picsum.photos/seed/mit/200/80' },
  ];

  return (
    <div className="bg-white">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] md:h-[70vh] text-white flex items-center">
            <div className="absolute inset-0 bg-black opacity-50"></div>
            <img src="https://picsum.photos/seed/hero-bg/1920/1080" alt="خلفية تعليمية" className="absolute inset-0 w-full h-full object-cover"/>
            <div className="container mx-auto px-6 text-center relative z-10">
                <h1 className="text-4xl md:text-6xl font-extrabold mb-4 leading-tight">
                    بوابتك نحو التميز العلمي والمهني
                </h1>
                <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8">
                    انضم إلى أكبر منصة تعليمية تفاعلية للباحثين والمتخصصين في العالم العربي.
                </p>
                <Link to="/courses" className="inline-block bg-primary-600 text-white font-bold py-3 px-8 rounded-full hover:bg-primary-700 transition-transform transform hover:scale-105">
                    استكشف الدورات
                </Link>
            </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <AnimatedStat finalValue={10523} label="طالب نشط" />
                <AnimatedStat finalValue={512} label="دورة متاحة" />
                <AnimatedStat finalValue={120} label="مدرب خبير" />
            </div>
          </div>
        </section>


        {/* Categories Section */}
         <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">استكشف حسب الموضوع</h2>
              <p className="text-gray-600 mt-2">ابحث عن شغفك في مجالاتنا المتنوعة.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-8">
              {categories.map((category, index) => (
                <Link to="/courses" key={index} className="block bg-gray-50 hover:bg-primary-100 p-8 rounded-lg shadow-sm text-center transition-all duration-300 transform hover:-translate-y-2">
                  <div className="flex justify-center mb-4">{category.icon}</div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{category.title}</h3>
                  <p className="text-gray-500">{category.courses} دورة</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Courses Section */}
        <section className="bg-gray-50 py-20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">أبرز الدورات لدينا</h2>
               <p className="text-gray-600 mt-2">انضم إلى آلاف الطلاب الذين يطورون مهاراتهم معنا.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {MOCK_COURSES.slice(0, 6).map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
             <div className="text-center mt-12">
                <Link to="/courses" className="inline-block bg-primary-600 text-white font-bold py-3 px-8 rounded-full hover:bg-primary-700 transition-transform transform hover:scale-105">
                    عرض جميع الدورات
                </Link>
            </div>
          </div>
        </section>
        
        {/* Partners Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">شركاؤنا في النجاح</h2>
              <p className="text-gray-600 mt-2">نتعاون مع جامعات وشركات رائدة لتقديم أفضل محتوى تعليمي.</p>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-x-16 gap-y-8">
              {partners.map((partner, index) => (
                <a href="#" key={index} className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all duration-300">
                  <img src={partner.logoUrl} alt={partner.name} className="h-10 lg:h-12 object-contain" />
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-gray-50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-800">ماذا يقول طلابنا</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {testimonials.map((testimonial, index) => (
                         <div key={index} className="bg-white p-8 rounded-lg shadow-lg">
                            <p className="text-gray-600 italic mb-6">"{testimonial.quote}"</p>
                            <div className="flex items-center">
                                <img src={testimonial.avatarUrl} alt={testimonial.name} className="w-14 h-14 rounded-full object-cover" />
                                <div className="mr-4">
                                    <h4 className="font-bold text-gray-800">{testimonial.name}</h4>
                                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
