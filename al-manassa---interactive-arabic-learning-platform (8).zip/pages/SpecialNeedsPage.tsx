
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { HeartIcon } from '../components/icons/HeartIcon';

const SpecialNeedsPage: React.FC = () => {
    return (
        <div className="bg-slate-50 min-h-screen">
            <Header />
            <main className="container mx-auto p-8">
                <div className="max-w-4xl mx-auto bg-white p-10 rounded-lg shadow-md text-center">
                    <HeartIcon className="w-16 h-16 text-primary-500 mx-auto mb-4" />
                    <h1 className="text-3xl font-bold mb-4">دعم الاحتياجات الخاصة</h1>
                    <p className="text-gray-600 leading-loose">
                        نحن ملتزمون بجعل التعليم متاحًا للجميع. توفر منصتنا ميزات لدعم المستخدمين من ذوي الاحتياجات الخاصة، بما في ذلك التوافق مع قارئات الشاشة، والترجمة النصية للفيديوهات، وخيارات لضبط حجم الخط والألوان.
                    </p>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default SpecialNeedsPage;
