
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseCard from '../components/CourseCard';
import { MOCK_COURSES } from '../constants';
import { EducationalStage } from '../types';

// Fix: Added missing 'continuous' property to satisfy the Record<EducationalStage, ...> type constraint
const stageDetails: Record<EducationalStage, { title: string; description: string; }> = {
    primary: {
        title: 'المرحلة الابتدائية',
        description: 'دورات تأسيسية وممتعة مصممة خصيصًا للأطفال لبدء رحلتهم التعليمية بحب وشغف.'
    },
    preparatory: {
        title: 'المرحلة الإعدادية',
        description: 'مناهج متقدمة تساعد الطلاب على بناء أساس علمي متين في مختلف المواد الأساسية.'
    },
    secondary: {
        title: 'المرحلة الثانوية',
        description: 'دورات متخصصة وشاملة لإعداد الطلاب للمرحلة الجامعية وتحقيق التميز الأكاديمي.'
    },
    academic: {
        title: 'المرحلة الأكاديمية والجامعية',
        description: 'محتوى متقدم للطلاب الجامعيين والباحثين يغطي أحدث التطورات في مختلف التخصصات.'
    },
    continuous: {
        title: 'التعليم المستمر',
        description: 'دورات تطوير مهني وشخصي تهدف لتعزيز المهارات والتعلم مدى الحياة في مختلف المجالات.'
    }
};

const EducationalStagePage: React.FC = () => {
  const { stageName } = useParams<{ stageName: string }>();

  if (!stageName || !Object.keys(stageDetails).includes(stageName)) {
    return (
        <>
            <Header />
            <div className="text-center py-20">
                <h1 className="text-2xl font-bold">المرحلة التعليمية غير موجودة</h1>
                <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">العودة للرئيسية</Link>
            </div>
            <Footer />
        </>
    );
  }

  const currentStage = stageName as EducationalStage;
  const details = stageDetails[currentStage];
  const filteredCourses = MOCK_COURSES.filter(course => course.stage === currentStage);

  return (
    <div className="bg-gray-50 min-h-screen">
      <Header />

      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800">{details.title}</h1>
          <p className="text-gray-600 mt-2 max-w-2xl mx-auto">{details.description}</p>
        </div>

        {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
            ))}
            </div>
        ) : (
            <div className="text-center py-16 bg-white rounded-lg shadow-md">
                <h3 className="text-2xl font-semibold text-gray-700">لا توجد دورات متاحة حاليًا</h3>
                <p className="text-gray-500 mt-2">نعمل على إضافة المزيد من الدورات لهذه المرحلة قريبًا.</p>
            </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default EducationalStagePage;
