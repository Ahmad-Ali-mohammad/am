
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { MOCK_LEARNING_PATHS_LIST, MOCK_COURSES } from '../constants';
import { PathCourse, PathCourseStatus } from '../types';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';
import { LockClosedIcon } from '../components/icons/LockClosedIcon';
import { TrophyIcon } from '../components/icons/TrophyIcon';
import { ShareIcon } from '../components/icons/ShareIcon';
import { ChatBubbleLeftRightIcon } from '../components/icons/ChatBubbleLeftRightIcon';

const StatusIcon: React.FC<{ status: PathCourseStatus }> = ({ status }) => {
    switch(status) {
        case 'completed': return <CheckCircleIcon className="w-8 h-8 text-white bg-green-500 rounded-full p-1" />;
        case 'in_progress': return (
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-full animate-pulse"></div>
            </div>
        );
        case 'locked': return <LockClosedIcon className="w-8 h-8 text-gray-400 bg-gray-200 rounded-full p-1.5" />;
        default: return null;
    }
};

const LearningPathDetailPage: React.FC = () => {
    const { pathId } = useParams<{ pathId: string }>();
    const path = MOCK_LEARNING_PATHS_LIST.find(p => p.id === pathId);

    if (!path) {
        return (
            <>
                <Header />
                <div className="flex items-center justify-center h-screen bg-gray-100">
                    <div className="text-center">
                        <h1 className="text-3xl font-bold text-gray-800 mb-4">المسار التعليمي غير موجود</h1>
                        <Link to="/learning-paths" className="mt-6 inline-block bg-primary-600 text-white font-bold py-2 px-6 rounded-md hover:bg-primary-700">
                            العودة للمسارات
                        </Link>
                    </div>
                </div>
                <Footer />
            </>
        );
    }

    const totalCourses = path.stages.reduce((acc, stage) => acc + stage.courses.length, 0);
    const completedCourses = path.stages.reduce((acc, stage) => acc + stage.courses.filter(c => c.status === 'completed').length, 0);
    const progressPercentage = totalCourses > 0 ? (completedCourses / totalCourses) * 100 : 0;
    const isPathCompleted = progressPercentage === 100;

    return (
        <div className="bg-slate-50 min-h-screen text-right" dir="rtl">
            <Header />
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="mb-8">
                    <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900">{path.title}</h1>
                    <p className="text-lg text-gray-600 mt-2">{path.description}</p>
                </div>

                <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
                    {/* Sticky Sidebar */}
                    <aside className="lg:w-1/3 lg:sticky top-24 self-start order-1 lg:order-2">
                        <div className="space-y-6">
                             <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg mb-4 text-gray-800">تقدمك في المسار</h3>
                                <div className="flex justify-between text-sm font-semibold mb-1">
                                    <span>{completedCourses} / {totalCourses} دورة مكتملة</span>
                                    <span>{Math.round(progressPercentage)}%</span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-4">
                                    <div className="bg-primary-600 h-4 rounded-full transition-all duration-500" style={{width: `${progressPercentage}%`}}></div>
                                </div>
                                 {isPathCompleted && (
                                     <div className="mt-6 text-center bg-green-50 p-4 rounded-md border border-green-200">
                                         <TrophyIcon className="w-12 h-12 text-yellow-500 mx-auto"/>
                                         <h4 className="font-bold text-green-800 mt-2">تهانينا! لقد أكملت المسار بنجاح.</h4>
                                         <button className="mt-3 w-full bg-green-600 text-white font-bold py-2 px-4 rounded-md hover:bg-green-700">احصل على شهادتك النهائية</button>
                                          <button className="mt-2 text-sm text-gray-500 hover:underline flex items-center justify-center w-full">
                                             <ShareIcon className="w-4 h-4 ml-1" /> شارك إنجازك
                                          </button>
                                     </div>
                                 )}
                            </div>
                             <div className="bg-white p-6 rounded-lg shadow-md">
                                 <h3 className="font-bold text-lg mb-4 text-gray-800">أدوات التعلم المتزامن</h3>
                                 <div className="space-y-3 text-sm">
                                    <p className="text-gray-700"><strong>الجلسات المباشرة:</strong> كل ثلاثاء، 7 مساءً</p>
                                    <button className="w-full flex items-center justify-center py-2 px-4 bg-blue-100 text-blue-800 font-semibold rounded-md hover:bg-blue-200">
                                        <ChatBubbleLeftRightIcon className="w-5 h-5 ml-2"/>
                                        اذهب إلى منتدى النقاش
                                    </button>
                                    <div className="pt-4 mt-2 border-t">
                                        <h4 className="font-semibold text-gray-800">المشروع الجماعي:</h4>
                                        <p className="text-gray-600 mt-1">"بناء نموذج تنبؤي" - موعد التسليم: 30 سبتمبر</p>
                                    </div>
                                 </div>
                             </div>
                             <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg mb-4 text-gray-800">مقارنة الأداء</h3>
                                <p className="text-sm text-gray-600 mb-4">تقدمك مقارنة بزملائك في المسار (بيانات مجهولة المصدر).</p>
                                <div>
                                    <div className="flex justify-between text-xs font-semibold mb-1">
                                        <span>أنت</span>
                                        <span>{Math.round(progressPercentage)}%</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                                        <div className="bg-primary-600 h-2.5 rounded-full" style={{width: `${progressPercentage}%`}}></div>
                                    </div>
                                </div>
                                <div className="mt-4">
                                     <div className="flex justify-between text-xs font-semibold mb-1">
                                        <span>متوسط الزملاء</span>
                                        <span>45%</span>
                                     </div>
                                     <div className="w-full bg-gray-200 rounded-full h-2.5">
                                        <div className="bg-yellow-500 h-2.5 rounded-full" style={{width: `45%`}}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>

                     {/* Main Content - Timeline */}
                    <main className="lg:w-2/3 order-2 lg:order-1">
                        <div className="relative pr-8 border-r-2 border-gray-200 mr-2">
                            {path.stages.map((stage, stageIndex) => (
                                <div key={stageIndex} className="mb-12 relative">
                                    {/* Stage Indicator */}
                                    <div className="absolute -right-[2.15rem] top-0 z-10 bg-primary-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold shadow-md border-4 border-slate-50">
                                        {stageIndex + 1}
                                    </div>
                                    
                                    <div className="mb-6">
                                        <h2 className="text-2xl font-bold text-gray-800 mr-4">{stage.title}</h2>
                                    </div>

                                    <div className="space-y-6">
                                        {stage.courses.map((pathCourse: PathCourse, courseIndex: number) => {
                                            const course = MOCK_COURSES.find(c => c.id === pathCourse.courseId);
                                            if (!course) return null;
                                            return (
                                                <div key={courseIndex} className="flex items-start">
                                                    <div className="z-10 mt-1">
                                                        <StatusIcon status={pathCourse.status} />
                                                    </div>
                                                    <div className={`mr-6 flex-1 bg-white p-5 rounded-lg shadow-sm border ${pathCourse.status === 'in_progress' ? 'border-blue-500 ring-2 ring-blue-100' : 'border-gray-100'}`}>
                                                        <h4 className="font-bold text-gray-900 text-lg">{course.title}</h4>
                                                        <p className="text-sm text-gray-500 mt-1">{course.instructor} • {course.duration}</p>
                                                        {pathCourse.prerequisites.length > 0 && (
                                                            <div className="mt-2 flex items-center text-xs text-amber-700 bg-amber-50 px-2 py-1 rounded">
                                                                <LockClosedIcon className="w-3 h-3 ml-1" />
                                                                <span>يتطلب إكمال: {pathCourse.prerequisites.join(', ')}</span>
                                                            </div>
                                                        )}
                                                         <Link to={`/course/${course.id}`} className={`mt-4 inline-block text-sm font-bold px-4 py-2 rounded transition-colors ${pathCourse.status === 'locked' ? 'bg-gray-100 text-gray-400 cursor-not-allowed pointer-events-none' : 'bg-primary-50 text-primary-600 hover:bg-primary-100'}`}>
                                                            {pathCourse.status === 'completed' ? 'مراجعة الدورة' : pathCourse.status === 'locked' ? 'مغلق' : 'ابدأ التعلم الآن'}
                                                        </Link>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {stage.certificateName && (
                                        <div className="mt-8 flex items-start">
                                            <div className="z-10 mt-1">
                                                <TrophyIcon className="w-8 h-8 text-yellow-600 bg-yellow-100 rounded-full p-1.5 shadow-sm" />
                                            </div>
                                            <div className="mr-6 flex-1 p-5 rounded-lg bg-gradient-to-l from-yellow-50 to-white border border-yellow-200">
                                                <h4 className="font-bold text-yellow-800">إنجاز المرحلة</h4>
                                                <p className="text-sm text-yellow-700 mt-1">أكمل جميع دورات هذه المرحلة للحصول على: <strong>{stage.certificateName}</strong></p>
                                                 <button 
                                                    className={`mt-3 text-sm font-bold px-4 py-2 rounded transition-all ${stage.courses.every(c => c.status === 'completed') ? 'bg-yellow-500 text-white hover:bg-yellow-600' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                                                    disabled={!stage.courses.every(c => c.status === 'completed')}
                                                 >
                                                    إصدار الشهادة
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </main>

                </div>
            </div>
            <Footer />
        </div>
    );
};

export default LearningPathDetailPage;
