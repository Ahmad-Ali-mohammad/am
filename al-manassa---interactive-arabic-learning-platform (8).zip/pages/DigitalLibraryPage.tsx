
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { MOCK_LIBRARY_RESOURCES } from '../constants';
import { LibraryResource, ResourceType } from '../types';
import { useAuth } from '../contexts/AuthContext';


const resourceTypes: ResourceType[] = ['كتاب', 'بحث', 'مقالة', 'فيديو'];

const DigitalLibraryPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedType, setSelectedType] = useState<ResourceType | 'الكل'>('الكل');
    const { user } = useAuth();
    const navigate = useNavigate();

    const filteredItems = MOCK_LIBRARY_RESOURCES
        .filter(item => 
            selectedType === 'الكل' || item.type === selectedType
        )
        .filter(item => 
            item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.author.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
    const handleDownloadClick = () => {
        if (!user) {
            navigate('/login');
        } else {
            // In a real app, this would trigger a download
            alert('بدء التنزيل (محاكاة)...');
        }
    }

    return (
        <div className="bg-slate-50 min-h-screen">
            <Header />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">المكتبة الرقمية</h1>
                    <p className="mt-4 text-lg text-gray-600">
                        مجموعة منسقة من الكتب، الأوراق البحثية، والمقالات لدعم رحلتك التعليمية.
                    </p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-md mb-10 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
                     <div className="relative flex-grow">
                        <input
                            type="text"
                            placeholder="ابحث في المكتبة..."
                            className="w-full px-5 py-3 border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center justify-center space-x-2 space-x-reverse">
                         <button onClick={() => setSelectedType('الكل')} className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${selectedType === 'الكل' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>الكل</button>
                        {resourceTypes.map(type => (
                             <button key={type} onClick={() => setSelectedType(type)} className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${selectedType === type ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>{type}</button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                    {filteredItems.map(item => (
                        <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden group transition-transform transform hover:-translate-y-1">
                            <div className="relative">
                                <img src={item.imageUrl} alt={item.title} className="w-full h-64 object-cover" />
                                <span className="absolute top-2 left-2 bg-primary-500 text-white text-xs font-semibold px-2 py-1 rounded-full">{item.type}</span>
                            </div>
                            <div className="p-4 flex flex-col h-40">
                                <h3 className="text-lg font-bold text-gray-800 group-hover:text-primary-600 flex-grow">{item.title}</h3>
                                <p className="text-sm text-gray-500 mb-3">{item.author}</p>
                                <button onClick={handleDownloadClick} className="w-full bg-primary-600 text-white font-semibold py-2 rounded-md hover:bg-primary-700 transition-colors">
                                    {user ? 'تحميل' : 'تسجيل الدخول للتنزيل'}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {filteredItems.length === 0 && (
                    <div className="text-center bg-white p-8 rounded-lg shadow-md col-span-full">
                        <h3 className="text-xl font-semibold text-gray-700">لا توجد نتائج مطابقة</h3>
                        <p className="text-gray-500 mt-2">حاول البحث بمصطلح آخر أو تغيير الفلتر.</p>
                    </div>
                )}
            </main>
            <Footer />
        </div>
    );
};

export default DigitalLibraryPage;
