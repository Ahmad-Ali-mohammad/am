
import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';

const PricingPage: React.FC = () => {
    const [isAnnual, setIsAnnual] = useState(false);

    const plans = [
        {
            name: 'الأساسي',
            price: { monthly: 15, annual: 150 },
            description: 'للمبتدئين الذين يبدأون رحلتهم التعليمية.',
            features: [
                'الوصول إلى 5 دورات شهرياً',
                'مواد تعليمية أساسية',
                'شهادة إتمام للدورات',
                'دعم عبر البريد الإلكتروني'
            ],
            buttonText: 'ابدأ الآن'
        },
        {
            name: 'الاحترافي',
            price: { monthly: 45, annual: 450 },
            description: 'للمتعلمين الجادين والباحثين المتخصصين.',
            features: [
                'وصول غير محدود لجميع الدورات',
                'الوصول الكامل للمكتبة الرقمية',
                'مشاريع عملية وواجبات',
                'دعم فوري وأولوية'
            ],
            buttonText: 'اختر الخطة الاحترافية',
            popular: true
        },
        {
            name: 'للمؤسسات',
            price: { monthly: 0, annual: 0 }, // Custom price
            description: 'حلول مخصصة للجامعات والشركات.',
            features: [
                'حسابات متعددة للفريق',
                'لوحة تحكم إدارية خاصة',
                'تقارير مخصصة للتقدم',
                'مدير حساب مخصص'
            ],
            buttonText: 'تواصل مع المبيعات'
        }
    ];

    return (
        <div className="bg-gray-50">
            <Header />
            <main>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">
                        اختر الخطة التي تناسبك
                    </h1>
                    <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                        استثمر في مستقبلك. ابدأ التعلم اليوم مع خطط مرنة مصممة لتلبية احتياجاتك.
                    </p>

                    <div className="mt-10 flex justify-center items-center space-x-4 space-x-reverse">
                        <span className="text-lg font-medium">شهري</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" checked={isAnnual} onChange={() => setIsAnnual(!isAnnual)} className="sr-only peer" />
                            <div className="w-14 h-8 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-1 after:right-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-primary-600"></div>
                        </label>
                        <span className="text-lg font-medium">
                            سنوي <span className="text-success-500 font-bold">(خصم 20%)</span>
                        </span>
                    </div>
                </div>

                <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-20">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
                        {plans.map((plan, index) => (
                            <div key={index} className={`bg-white rounded-lg shadow-lg p-8 flex flex-col ${plan.popular ? 'border-4 border-primary-500' : 'border'}`}>
                                {plan.popular && (
                                    <span className="bg-primary-500 text-white text-xs font-bold px-3 py-1 rounded-full self-center mb-4 -mt-12">الأكثر شيوعاً</span>
                                )}
                                <h3 className="text-2xl font-bold text-gray-800 text-center">{plan.name}</h3>
                                <div className="mt-4 text-center">
                                    {plan.name === 'للمؤسسات' ? (
                                         <span className="text-4xl font-extrabold">مخصص</span>
                                    ) : (
                                        <>
                                            <span className="text-4xl font-extrabold">${isAnnual ? plan.price.annual : plan.price.monthly}</span>
                                            <span className="text-gray-500">/ {isAnnual ? 'سنوياً' : 'شهرياً'}</span>
                                        </>
                                    )}
                                </div>
                                <p className="mt-4 text-gray-600 text-center h-12">{plan.description}</p>
                                
                                <ul className="mt-8 space-y-4 flex-grow">
                                    {plan.features.map((feature, fIndex) => (
                                        <li key={fIndex} className="flex items-start">
                                            <CheckCircleIcon className="w-6 h-6 text-success-500 ml-3 flex-shrink-0" />
                                            <span className="text-gray-700">{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                                <button className={`mt-8 w-full py-3 px-6 rounded-lg font-bold text-lg transition-colors ${plan.popular ? 'bg-primary-600 text-white hover:bg-primary-700' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}`}>
                                    {plan.buttonText}
                                </button>
                            </div>
                        ))}
                    </div>
                </div>

            </main>
            <Footer />
        </div>
    );
};

export default PricingPage;
