
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { Cog6ToothIcon } from '../components/icons/Cog6ToothIcon';
import { UserCircleIcon } from '../components/icons/UserCircleIcon';
import { AcademicCapIcon } from '../components/icons/AcademicCapIcon';
import { TrophyIcon } from '../components/icons/TrophyIcon';
import { ClockIcon } from '../components/icons/ClockIcon';
import { BookOpenIcon } from '../components/icons/BookOpenIcon';
import { StarIcon } from '../components/icons/StarIcon';
import { ChartPieIcon } from '../components/icons/ChartPieIcon';
import { CurrencyDollarIcon } from '../components/icons/CurrencyDollarIcon';
import { MegaphoneIcon } from '../components/icons/MegaphoneIcon';
import { MOCK_ACHIEVEMENTS, MOCK_ACTIVITIES, MOCK_COURSES } from '../constants';
import { UserRole } from '../types';

// --- Student Profile Components ---
const StudentProfile: React.FC = () => {
    const [activeTab, setActiveTab] = useState('overview');
    const tabs = [
        { id: 'overview', label: 'نظرة عامة', icon: <UserCircleIcon className="w-5 h-5 ml-2" /> },
        { id: 'education', label: 'التعليم', icon: <AcademicCapIcon className="w-5 h-5 ml-2" /> },
        { id: 'certificates', label: 'الشهادات', icon: <TrophyIcon className="w-5 h-5 ml-2" /> },
        { id: 'activity', label: 'النشاط', icon: <ClockIcon className="w-5 h-5 ml-2" /> },
        { id: 'settings', label: 'الإعدادات', icon: <Cog6ToothIcon className="w-5 h-5 ml-2" /> },
    ];

    return (
        <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
            <div className="border-b border-gray-200 mb-8">
                <nav className="-mb-px flex space-x-6 space-x-reverse overflow-x-auto" aria-label="Tabs">
                    {tabs.map(tab => (
                        <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`whitespace-nowrap flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.id ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                           {tab.icon} {tab.label}
                        </button>
                    ))}
                </nav>
            </div>

            {activeTab === 'overview' && <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-6">أحدث الإنجازات</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {MOCK_ACHIEVEMENTS.map(ach => (
                        <div key={ach.id} className="bg-gray-50 p-4 rounded-lg flex items-center">
                            <div className="bg-yellow-100 p-3 rounded-full ml-4">
                               {ach.icon === 'trophy' && <TrophyIcon className="w-6 h-6 text-yellow-500"/>}
                               {ach.icon === 'academic_cap' && <AcademicCapIcon className="w-6 h-6 text-yellow-500"/>}
                               {ach.icon === 'star' && <StarIcon className="w-6 h-6 text-yellow-500"/>}
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-800">{ach.title}</h3>
                                <p className="text-sm text-gray-500">{ach.date}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>}
            {activeTab === 'education' && <div>
                 <h2 className="text-2xl font-bold text-gray-800 mb-6">الدورات الحالية والمكتملة</h2>
                 <p>محتوى التعليم هنا...</p>
            </div>}
            {activeTab === 'certificates' && <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-6">معرض الشهادات</h2>
                <p>قائمة بالشهادات التي تم الحصول عليها...</p>
            </div>}
            {activeTab === 'activity' && <div>
                 <h2 className="text-2xl font-bold text-gray-800 mb-6">سجل النشاط</h2>
                 <ul className="space-y-4">
                    {MOCK_ACTIVITIES.map(act => (
                        <li key={act.id} className="flex items-center p-3 bg-gray-50 rounded-md">
                            <span className="text-gray-800">{act.action} <Link to="#" className="font-semibold text-primary-600">{act.target}</Link></span>
                            <span className="text-sm text-gray-500 mr-auto">{act.date}</span>
                        </li>
                    ))}
                 </ul>
            </div>}
            {activeTab === 'settings' && <div><h2 className="text-2xl font-bold text-gray-800 mb-6">إعدادات الحساب</h2><p>نموذج إعدادات الحساب...</p></div>}
        </div>
    );
}

// --- Instructor Profile Components ---
const InstructorProfile: React.FC = () => {
    const [activeTab, setActiveTab] = useState('portfolio');
     const tabs = [
        { id: 'portfolio', label: 'البورتفوليو', icon: <UserCircleIcon className="w-5 h-5 ml-2" /> },
        { id: 'courses', label: 'الدورات', icon: <BookOpenIcon className="w-5 h-5 ml-2" /> },
        { id: 'students', label: 'الطلاب', icon: <AcademicCapIcon className="w-5 h-5 ml-2" /> },
        { id: 'revenue', label: 'الإيرادات', icon: <CurrencyDollarIcon className="w-5 h-5 ml-2" /> },
        { id: 'reputation', label: 'السمعة', icon: <MegaphoneIcon className="w-5 h-5 ml-2" /> },
        { id: 'settings', label: 'الإعدادات', icon: <Cog6ToothIcon className="w-5 h-5 ml-2" /> },
    ];
    
    return (
         <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
            <div className="border-b border-gray-200 mb-8">
                <nav className="-mb-px flex space-x-6 space-x-reverse overflow-x-auto" aria-label="Tabs">
                    {tabs.map(tab => (
                        <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`whitespace-nowrap flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.id ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                           {tab.icon} {tab.label}
                        </button>
                    ))}
                </nav>
            </div>

            {activeTab === 'portfolio' && <div>
                 <h2 className="text-2xl font-bold text-gray-800 mb-6">نظرة عامة على الأداء</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="bg-gray-50 p-4 rounded-lg"><p className="text-2xl font-bold">4.7</p><p className="text-sm text-gray-500">متوسط التقييم</p></div>
                    <div className="bg-gray-50 p-4 rounded-lg"><p className="text-2xl font-bold">1,800</p><p className="text-sm text-gray-500">طالب</p></div>
                    <div className="bg-gray-50 p-4 rounded-lg"><p className="text-2xl font-bold">2</p><p className="text-sm text-gray-500">دورة منشورة</p></div>
                    <div className="bg-gray-50 p-4 rounded-lg"><p className="text-2xl font-bold">15</p><p className="text-sm text-gray-500">مراجعة</p></div>
                </div>
            </div>}
            {activeTab === 'courses' && <div><h2 className="text-2xl font-bold text-gray-800 mb-6">إدارة الدورات</h2><p>قائمة بدورات المدرس...</p></div>}
            {activeTab === 'revenue' && <div><h2 className="text-2xl font-bold text-gray-800 mb-6">تحليل الإيرادات</h2><p>رسوم بيانية وتقارير مالية...</p></div>}
            {activeTab === 'reputation' && <div><h2 className="text-2xl font-bold text-gray-800 mb-6">تقييمات الطلاب</h2><p>قائمة بتقييمات الطلاب والرد عليها...</p></div>}
            {activeTab === 'settings' && <div><h2 className="text-2xl font-bold text-gray-800 mb-6">إعدادات الحساب المهني</h2><p>نموذج إعدادات حساب المدرس...</p></div>}
         </div>
    );
}


// --- Main Profile Page ---
const ProfilePage: React.FC = () => {
    const { user } = useAuth();

    if (!user) {
        return <div>Loading...</div>;
    }
    
    return (
        <>
            <div className="bg-white rounded-lg shadow-md p-6 md:p-8 mb-8">
                 <div className="flex flex-col md:flex-row items-center">
                    <img src={user.avatarUrl} alt={user.name} className="w-24 h-24 rounded-full object-cover border-4 border-primary-500" />
                    <div className="mt-4 md:mt-0 md:mr-6 text-center md:text-right">
                        <h1 className="text-3xl font-bold text-gray-900">{user.name}</h1>
                        <p className="text-gray-600">{user.email}</p>
                        <span className="mt-2 inline-block bg-gray-200 text-gray-800 text-sm font-semibold px-3 py-1 rounded-full">{user.role}</span>
                    </div>
                </div>
            </div>

            {user.role === UserRole.STUDENT && <StudentProfile />}
            {user.role === UserRole.INSTRUCTOR && <InstructorProfile />}
            {(user.role === UserRole.ADMIN || user.role === UserRole.CONTENT_MANAGER) && (
                <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
                     <h2 className="text-2xl font-bold text-gray-800 mb-6">ملف المشرف</h2>
                     <p>المعلومات الأساسية للمشرف أو مدير المحتوى.</p>
                </div>
            )}
        </>
    );
};

export default ProfilePage;
