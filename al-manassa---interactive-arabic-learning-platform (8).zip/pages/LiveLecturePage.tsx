
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useParams } from 'react-router-dom';

const LiveLecturePage: React.FC = () => {
    const { lectureId } = useParams();
    return (
        <div className="bg-gray-100 min-h-screen">
            <Header />
            <main className="container mx-auto p-8">
                <h1 className="text-3xl font-bold mb-4">البث المباشر: مقدمة في الذكاء الاصطناعي (محاكاة)</h1>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 bg-black rounded-lg h-96 flex items-center justify-center text-white shadow-lg">
                        [Video Player Placeholder for Lecture ID: {lectureId}]
                    </div>
                    <div className="bg-white rounded-lg p-6 shadow-md">
                        <h2 className="font-bold text-xl mb-4 border-b pb-2">الأسئلة والأجوبة</h2>
                        <div className="space-y-4 h-80 overflow-y-auto">
                           {/* Chat messages would go here */}
                           <p className="text-sm text-gray-500 text-center pt-16">لا توجد رسائل بعد.</p>
                        </div>
                         <div className="mt-4">
                            <input type="text" placeholder="اكتب سؤالك..." className="w-full p-2 border rounded-md" />
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default LiveLecturePage;
