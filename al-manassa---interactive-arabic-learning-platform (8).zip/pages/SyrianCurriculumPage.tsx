import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { SYRIAN_CURRICULUM_DATA, CurriculumNode, Lesson } from '../data/curriculumData';
import { ChevronDownIcon } from '../components/icons/ChevronDownIcon';
import { FolderIcon } from '../components/icons/FolderIcon';
import { DocumentIcon } from '../components/icons/DocumentIcon';
import { BookOpenIcon } from '../components/icons/BookOpenIcon';
import { VideoCameraIcon } from '../components/icons/VideoCameraIcon';
import { PencilSquareIcon } from '../components/icons/PencilSquareIcon';
import { CheckBadgeIcon } from '../components/icons/CheckBadgeIcon';
import { LightBulbIcon } from '../components/icons/LightBulbIcon';
import { NewspaperIcon } from '../components/icons/NewspaperIcon';
import { QuestionMarkCircleIcon } from '../components/icons/QuestionMarkCircleIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';


type ContentTab = 'book' | 'explanation' | 'exercises' | 'media';

// Helper function to find the path to a node
function findNodePath(nodes: CurriculumNode[], nodeId: string): CurriculumNode[] {
    for (const node of nodes) {
        if (node.id === nodeId) {
            return [node];
        }
        if ('children' in node && node.children) {
            const path = findNodePath(node.children, nodeId);
            if (path.length > 0) {
                return [node, ...path];
            }
        }
    }
    return [];
}


// Recursive Tree Node Component
const TreeNode: React.FC<{ node: CurriculumNode; onSelect: (node: CurriculumNode) => void; selectedId: string | null; level: number }> = ({ node, onSelect, selectedId, level }) => {
    const [isOpen, setIsOpen] = useState(level < 2);
    const isSelected = selectedId === node.id;
    const hasChildren = 'children' in node && node.children.length > 0;
    
    const getIcon = () => {
        const selectedClasses = 'text-white';
        switch(node.type) {
            case 'lesson': return <DocumentIcon className={`w-5 h-5 ${isSelected ? 'text-primary-100' : 'text-slate-500'}`} />;
            default: return <FolderIcon className={`w-5 h-5 ${isSelected ? selectedClasses : (level === 0 ? 'text-primary-600' : 'text-yellow-500')}`} />;
        }
    };

    return (
        <div className={level > 0 ? "mr-3" : ""}>
            <div 
                className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-all ${isSelected ? 'bg-primary-600 text-white shadow-md' : 'hover:bg-slate-100'}`}
                onClick={() => onSelect(node)}
            >
                <div className="flex items-center">
                    <div className="ml-2">{getIcon()}</div>
                    <span className={`text-sm font-semibold ${isSelected ? 'text-white' : 'text-slate-700'}`}>{node.title}</span>
                </div>
                {hasChildren && (
                     <button onClick={(e) => { e.stopPropagation(); setIsOpen(!isOpen); }} className={`p-1 rounded-full ${isSelected ? 'hover:bg-primary-500' : 'hover:bg-slate-200'}`}>
                        <ChevronDownIcon className={`w-4 h-4 transition-transform ${isOpen ? '' : '-rotate-90'} ${isSelected ? 'text-white' : 'text-slate-500'}`} />
                     </button>
                )}
            </div>
            {isOpen && hasChildren && (
                <div className="mt-1 space-y-1 border-r-2 border-slate-200/80">
                    {'children' in node && node.children.map(child => <TreeNode key={child.id} node={child} onSelect={onSelect} selectedId={selectedId} level={level + 1} />)}
                </div>
            )}
        </div>
    );
};


// Content Viewer Component
const ContentViewer: React.FC<{ lesson: Lesson | null }> = ({ lesson }) => {
    const [activeTab, setActiveTab] = useState<ContentTab>('book');
    const [showSolution, setShowSolution] = useState<number | null>(null);

    if (!lesson) {
        return (
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 h-full flex flex-col items-center justify-center text-center">
                <BookOpenIcon className="w-28 h-28 text-slate-200" />
                <h2 className="text-2xl font-bold text-slate-800 mt-4">مستكشف المنهج السوري</h2>
                <p className="text-slate-500 mt-2 max-w-sm">اختر درسًا من القائمة الجانبية لبدء رحلتك في تصفح المحتوى الدراسي المطور.</p>
            </div>
        );
    }
    
    const tabs: {id: ContentTab, label: string, icon: React.ReactNode}[] = [
        {id: 'book', label: 'الكتاب المدرسي', icon: <BookOpenIcon className="w-5 h-5"/>},
        {id: 'explanation', label: 'شرح تفصيلي', icon: <SparklesIcon className="w-5 h-5"/>},
        {id: 'exercises', label: 'تمارين وحلول', icon: <PencilSquareIcon className="w-5 h-5"/>},
        {id: 'media', label: 'وسائط متعددة', icon: <VideoCameraIcon className="w-5 h-5"/>},
    ];

    const breadcrumbPath = findNodePath(SYRIAN_CURRICULUM_DATA, lesson.id);

    return (
         <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-slate-100">
             {/* Breadcrumbs */}
             <nav className="mb-4 text-xs font-semibold text-slate-500 flex items-center flex-wrap">
                {breadcrumbPath.map((node, index) => (
                    <React.Fragment key={node.id}>
                        <span>{node.title}</span>
                        {index < breadcrumbPath.length - 1 && <ChevronDownIcon className="w-4 h-4 mx-1 transform -rotate-90" />}
                    </React.Fragment>
                ))}
             </nav>
            
            <h1 className="text-3xl lg:text-4xl font-black text-slate-900 mb-6">{lesson.title}</h1>
            
            <div className="bg-slate-100 p-1.5 rounded-xl flex items-center gap-2 overflow-x-auto no-scrollbar mb-8">
                {tabs.map(tab => (
                    <button 
                        key={tab.id} 
                        onClick={() => setActiveTab(tab.id)} 
                        className={`flex-1 sm:flex-none flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${activeTab === tab.id ? 'bg-white text-primary-700 shadow-sm' : 'text-slate-500 hover:bg-white/60'}`}
                    >
                        {tab.icon} {tab.label}
                    </button>
                ))}
            </div>
            
            <div className="prose prose-lg max-w-none prose-cairo">
                {activeTab === 'book' && <div className="p-8 bg-slate-100 rounded-lg text-center border-2 border-dashed"><h3 className="font-bold">محتوى الكتاب المدرسي (محاكاة)</h3><p>{lesson.content.text}</p></div>}
                {activeTab === 'explanation' && <div className="p-6 bg-blue-50/50 border-r-4 border-blue-400 rounded-r-lg"><h4 className="font-bold text-blue-900">شرح تفصيلي:</h4><p className="text-slate-700">{lesson.content.explanation}</p></div>}
                {activeTab === 'exercises' && (
                    <div className="space-y-4">
                        {lesson.content.exercises.map((ex, i) => (
                            <div key={i} className="p-4 border rounded-lg bg-slate-50/70">
                                <p className="font-semibold text-slate-800">{i+1}. {ex.q}</p>
                                <button onClick={() => setShowSolution(showSolution === i ? null : i)} className="text-sm text-primary-600 font-bold mt-3 flex items-center gap-2">
                                    <LightBulbIcon className="w-4 h-4"/>
                                    {showSolution === i ? 'إخفاء الحل' : 'إظهار الحل'}
                                </button>
                                {showSolution === i && <div className="mt-3 p-4 bg-green-50 text-green-800 rounded-md border border-green-200 prose-base">{ex.a}</div>}
                            </div>
                        ))}
                    </div>
                )}
                {activeTab === 'media' && (
                    <div>
                        {lesson.content.media.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {lesson.content.media.map((mediaItem, index) => (
                                    <div key={index} className="bg-slate-50 p-3 rounded-xl border">
                                        {mediaItem.type === 'image' && (
                                            <img src={mediaItem.url} alt={`وسائط الدرس ${index + 1}`} className="rounded-lg w-full h-auto object-cover shadow-md" />
                                        )}
                                        {mediaItem.type === 'video' && (
                                            <iframe
                                                src={mediaItem.url}
                                                title={`وسائط الدرس ${index + 1}`}
                                                frameBorder="0"
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                allowFullScreen
                                                className="rounded-lg w-full h-64 shadow-md"
                                            ></iframe>
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="p-8 bg-slate-100 rounded-lg text-center border-2 border-dashed">
                                <h3 className="font-bold text-slate-600">لا توجد وسائط متعددة لهذا الدرس.</h3>
                            </div>
                        )}
                    </div>
                )}
            </div>

             <div className="mt-10 pt-8 border-t border-slate-200">
                <h3 className="text-xl font-bold flex items-center gap-2 text-slate-800"><CheckBadgeIcon className="w-6 h-6 text-green-500"/> الأهداف التعليمية للدرس</h3>
                <ul className="mt-4 space-y-3">
                    {lesson.objectives.map((obj, i) => (
                        <li key={i} className="flex items-start">
                           <CheckBadgeIcon className="w-5 h-5 text-green-400 ml-3 mt-1 flex-shrink-0"/>
                           <span className="text-slate-600">{obj}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};


// Student Tools Component
const StudentTools: React.FC = () => {
    const tools = [
        {title: 'بنوك الأسئلة', icon: <NewspaperIcon className="w-8 h-8"/>, color: 'text-blue-500', bgColor: 'bg-blue-50'},
        {title: 'نماذج امتحانية', icon: <DocumentIcon className="w-8 h-8"/>, color: 'text-green-500', bgColor: 'bg-green-50'},
        {title: 'نصائح دراسية', icon: <LightBulbIcon className="w-8 h-8"/>, color: 'text-yellow-500', bgColor: 'bg-yellow-50'},
        {title: 'اسأل مدرّس', icon: <QuestionMarkCircleIcon className="w-8 h-8"/>, color: 'text-purple-500', bgColor: 'bg-purple-50'}
    ];
    return (
        <section className="mt-16">
             <h2 className="text-3xl font-bold text-slate-800 mb-8 border-r-4 border-primary-500 pr-4">صندوق أدوات الطالب</h2>
             <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {tools.map(tool => (
                    <div key={tool.title} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center hover:shadow-xl hover:-translate-y-2 transition-all cursor-pointer group">
                        <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-5 transition-colors ${tool.bgColor} group-hover:bg-primary-50`}>
                           <div className={`${tool.color} group-hover:text-primary-600 transition-colors`}>{tool.icon}</div>
                        </div>
                        <h3 className="font-bold text-slate-800 transition-colors group-hover:text-primary-600">{tool.title}</h3>
                    </div>
                ))}
             </div>
        </section>
    );
}

// Main Page Component
const SyrianCurriculumPage: React.FC = () => {
    const [selectedNode, setSelectedNode] = useState<CurriculumNode | null>(null);

    return (
        <div className="bg-slate-50 min-h-screen" dir="rtl">
            <Header />
            <main className="container mx-auto px-4 py-8">
                 <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4">المنهج الدراسي السوري الرسمي</h1>
                    <p className="text-lg text-slate-600 max-w-2xl mx-auto">تصفح، تعلم، وتفوق مع دليلنا الشامل للمناهج السورية المعتمدة.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
                    {/* Sidebar */}
                    <aside className="lg:col-span-1">
                        <div className="sticky top-24 bg-white p-4 rounded-2xl shadow-sm border border-slate-100 h-[calc(100vh-7rem)] overflow-y-auto custom-scrollbar">
                            <h2 className="text-lg font-bold text-slate-800 mb-4 px-2">شجرة المناهج</h2>
                            {SYRIAN_CURRICULUM_DATA.map(node => <TreeNode key={node.id} node={node} onSelect={setSelectedNode} selectedId={selectedNode?.id || null} level={0} />)}
                        </div>
                    </aside>

                    {/* Main Content */}
                    <main className="lg:col-span-3 space-y-12">
                       <ContentViewer lesson={selectedNode?.type === 'lesson' ? selectedNode as Lesson : null} />
                       <StudentTools />
                    </main>
                </div>
            </main>
            <Footer />
            <style dangerouslySetInnerHTML={{ __html: `
                .prose-cairo { font-family: 'Cairo', sans-serif; }
                .custom-scrollbar::-webkit-scrollbar { width: 6px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
                .no-scrollbar::-webkit-scrollbar { display: none; }
                .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
            `}} />
        </div>
    );
};

export default SyrianCurriculumPage;