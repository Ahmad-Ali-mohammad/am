
import React from 'react';
import { WrenchScrewdriverIcon } from '../components/icons/WrenchScrewdriverIcon';

const MaintenancePage: React.FC = () => {
    return (
        <div className="bg-slate-100 min-h-screen flex items-center justify-center text-center">
            <div>
                <WrenchScrewdriverIcon className="w-24 h-24 text-primary-400 mx-auto mb-6 animate-pulse" />
                <h1 className="text-4xl font-extrabold text-slate-800 mb-4">المنصة قيد الصيانة حاليًا</h1>
                <p className="text-slate-600 max-w-md mx-auto">
                    نحن نعمل على إجراء بعض التحسينات لجعل تجربتك أفضل. سنعود قريبًا!
                </p>
            </div>
        </div>
    );
};

export default MaintenancePage;
