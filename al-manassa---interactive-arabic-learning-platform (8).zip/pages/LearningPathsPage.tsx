
import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { MOCK_LEARNING_PATHS_LIST } from '../constants';
import { LearningPathDetailed } from '../types';
import { RoadIcon } from '../components/icons/RoadIcon';

const LearningPathCard: React.FC<{ path: LearningPathDetailed }> = ({ path }) => {
    return (
        <Link to={`/learning-paths/${path.id}`} className="block group bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300 flex flex-col">
            <img src={path.imageUrl} alt={path.title} className="w-full h-48 object-cover" />
            <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-primary-600 transition-colors h-16">{path.title}</h3>
                <p className="text-gray-600 text-sm flex-grow mb-4">{path.description}</p>
                <div className="flex justify-between items-center text-sm text-gray-500 border-t pt-4">
                    <span>{path.stages.length} مراحل</span>
                    <span>المدة: {path.totalDuration}</span>
                </div>
                <div className="mt-4 text-center">
                    <span className="w-full inline-block bg-primary-600 text-white font-bold py-2 px-6 rounded-lg group-hover:bg-primary-700 transition-colors">
                        ابدأ المسار
                    </span>
                </div>
            </div>
        </Link>
    );
};

const LearningPathsPage: React.FC = () => {
    return (
        <div className="bg-slate-50 min-h-screen">
            <Header />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <RoadIcon className="w-16 h-16 mx-auto text-primary-500" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mt-4">
                        المسارات التعليمية المتكاملة
                    </h1>
                    <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                        اختر مسارًا تعليميًا مصممًا بعناية من قبل الخبراء ليأخذك من الصفر إلى الاحتراف في المجال الذي تختاره.
                    </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {MOCK_LEARNING_PATHS_LIST.map(path => (
                        <LearningPathCard key={path.id} path={path} />
                    ))}
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default LearningPathsPage;
