
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { PlusCircleIcon } from '../components/icons/PlusCircleIcon';

const StudyGroupsPage: React.FC = () => {
    const mockGroups = [
        { name: 'مجموعة الخوارزميات المتقدمة', description: 'نستعد للامتحان النهائي ونناقش المسائل الصعبة.', members: 5 },
        { name: 'تحضير شهادة PMP', description: 'مجموعة مخصصة للمهتمين بالحصول على شهادة إدارة المشاريع الاحترافية.', members: 12 },
        { name: 'نادي الذكاء الاصطناعي', description: 'نقاشات أسبوعية حول أحدث الأوراق البحثية في مجال الذكاء الاصطناعي.', members: 8 },
    ];

    return (
        <div className="bg-slate-50 min-h-screen">
            <Header />
            <main className="container mx-auto p-8">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold">المجموعات الدراسية</h1>
                    <button className="flex items-center bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700">
                        <PlusCircleIcon className="w-5 h-5 ml-2" />
                        إنشاء مجموعة
                    </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {mockGroups.map((group, index) => (
                         <div key={index} className="bg-white p-6 rounded-lg shadow-md flex flex-col">
                            <h2 className="font-bold text-xl mb-2">{group.name}</h2>
                            <p className="text-gray-600 text-sm mb-4 flex-grow">{group.description}</p>
                            <div className="flex justify-between items-center text-sm border-t pt-4">
                                <div className="flex items-center text-gray-500">
                                    <UserGroupIcon className="w-5 h-5 mr-2"/>
                                    <span>{group.members} أعضاء</span>
                                </div>
                                <button className="font-bold text-primary-600 hover:underline">انضم الآن</button>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
            <Footer />
        </div>
    );
};
export default StudyGroupsPage;
