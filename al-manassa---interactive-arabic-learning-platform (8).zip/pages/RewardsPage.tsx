
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { GiftIcon } from '../components/icons/GiftIcon';
import { RocketLaunchIcon } from '../components/icons/RocketLaunchIcon';
import { ArrowUpCircleIcon } from '../components/icons/ArrowUpCircleIcon';
import { CheckBadgeIcon } from '../components/icons/CheckBadgeIcon';
import { DocumentPlusIcon } from '../components/icons/DocumentPlusIcon';
import { QuestionMarkCircleIcon } from '../components/icons/QuestionMarkCircleIcon';
import { ChatBubbleLeftRightIcon } from '../components/icons/ChatBubbleLeftRightIcon';

const RewardsPage: React.FC = () => {

    const howItWorksSteps = [
        { icon: <DocumentPlusIcon className="w-8 h-8 text-primary-600" />, title: "أضف محتوى", description: "ساهم بإضافة موارد تعليمية، دورات، أو مقالات في مجالك." },
        { icon: <QuestionMarkCircleIcon className="w-8 h-8 text-primary-600" />, title: "أجب على الأسئلة", description: "ساعد الآخرين من خلال الإجابة على استفساراتهم في المنتديات." },
        { icon: <ChatBubbleLeftRightIcon className="w-8 h-8 text-primary-600" />, title: "شارك في النقاشات", description: "تفاعل في النقاشات العلمية وأثرِ الحوار بآرائك وخبراتك." },
        { icon: <ArrowUpCircleIcon className="w-8 h-8 text-primary-600" />, title: "ارتقِ بالمستوى", description: "كلما ساهمت أكثر، زادت نقاطك وارتفع مستواك للحصول على مزايا أفضل." }
    ];

    const tiers = [
        { name: "المساهم البرونزي", points: "0+", perks: ["شارة الملف الشخصي", "الوصول للمنتدى الخاص"], color: "text-amber-700" },
        { name: "المساهم الفضي", points: "500+", perks: ["خصم 10% على الدورات", "أولوية في الدعم"], color: "text-slate-500" },
        { name: "المساهم الذهبي", points: "2,000+", perks: ["دورة مجانية شهرياً", "شارة ذهبية مميزة"], color: "text-yellow-500" },
        { name: "المساهم الماسي", points: "10,000+", perks: ["وصول كامل للمنصة", "دعوات لفعاليات حصرية"], color: "text-blue-600" }
    ];

    const rewards = [
        { name: "بطاقة خصم 25%", cost: "1,000 نقطة", icon: <GiftIcon className="w-12 h-12 text-primary-500"/> },
        { name: "دورة حصرية مجانية", cost: "2,500 نقطة", icon: <GiftIcon className="w-12 h-12 text-primary-500"/> },
        { name: "شهادة تقديرية خاصة", cost: "5,000 نقطة", icon: <GiftIcon className="w-12 h-12 text-primary-500"/> },
        { name: "استشارة مع خبير", cost: "7,500 نقطة", icon: <GiftIcon className="w-12 h-12 text-primary-500"/> },
    ];

    return (
        <div className="bg-slate-50 min-h-screen" dir="rtl">
            <Header />
            <main>
                {/* Hero Section */}
                <section className="bg-slate-900 text-white py-20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary-600 to-indigo-800 opacity-80"></div>
                     <div className="container mx-auto px-6 relative z-10 text-center">
                        <RocketLaunchIcon className="w-24 h-24 mx-auto text-primary-300 mb-6"/>
                        <h1 className="text-4xl md:text-6xl font-black mb-4">
                            ساهم وارتقِ: نظام المكافآت والتقدير
                        </h1>
                        <p className="text-xl text-slate-200 max-w-3xl mx-auto">
                            نؤمن بأن المعرفة تزدهر بالمشاركة. انضم إلى نخبة المساهمين، واكسب النقاط، واحصل على مكافآت حصرية تقديرًا لجهودك في إثراء المحتوى العلمي.
                        </p>
                    </div>
                </section>

                {/* How it works */}
                <section className="py-20">
                    <div className="container mx-auto px-6">
                        <div className="text-center mb-12">
                            <h2 className="text-3xl md:text-4xl font-bold text-slate-800">آلية عمل النظام</h2>
                            <p className="text-slate-600 mt-2">رحلتك نحو التميز تبدأ بخطوات بسيطة.</p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {howItWorksSteps.map((step, index) => (
                                <div key={index} className="bg-white p-8 rounded-2xl shadow-sm text-center border border-slate-100">
                                    <div className="bg-primary-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                                        {step.icon}
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-800 mb-2">{step.title}</h3>
                                    <p className="text-slate-500 text-sm">{step.description}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
                
                {/* Tiers Section */}
                <section className="bg-white py-20">
                    <div className="container mx-auto px-6">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl md:text-4xl font-bold text-slate-800">مستويات المساهمين</h2>
                            <p className="text-slate-600 mt-2">كل مستوى يفتح لك أبوابًا جديدة من المزايا والتقدير.</p>
                        </div>
                        <div className="relative">
                             <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-200 -translate-y-1/2"></div>
                             <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
                                 {tiers.map((tier, index) => (
                                     <div key={index} className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-primary-500 text-center">
                                        <h3 className={`text-2xl font-black ${tier.color}`}>{tier.name}</h3>
                                        <p className="font-bold text-slate-800 my-3">{tier.points} نقطة</p>
                                        <ul className="space-y-2 text-sm text-slate-600">
                                            {tier.perks.map((perk, pIndex) => (
                                                <li key={pIndex} className="flex items-center justify-center">
                                                    <CheckBadgeIcon className="w-5 h-5 ml-2 text-green-500" />
                                                    {perk}
                                                </li>
                                            ))}
                                        </ul>
                                     </div>
                                 ))}
                             </div>
                        </div>
                    </div>
                </section>


                {/* Rewards Showcase */}
                <section className="py-20 bg-slate-50">
                    <div className="container mx-auto px-6">
                        <div className="text-center mb-12">
                            <h2 className="text-3xl md:text-4xl font-bold text-slate-800">استبدل نقاطك بمكافآت قيمة</h2>
                            <p className="text-slate-600 mt-2">مكافآت مصممة خصيصاً لتعزيز مسيرتك العلمية والمهنية.</p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {rewards.map((reward, index) => (
                                <div key={index} className="bg-white p-8 rounded-2xl shadow-md text-center border-b-4 border-primary-300 hover:border-primary-500 transition-colors">
                                    <div className="mx-auto mb-4">
                                        {reward.icon}
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-800">{reward.name}</h3>
                                    <p className="text-primary-600 font-bold mt-2">{reward.cost}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* CTA Section */}
                <section className="py-20">
                    <div className="container mx-auto px-6 text-center">
                         <h2 className="text-3xl md:text-4xl font-black text-slate-800">هل أنت مستعد لتكون جزءًا من التغيير؟</h2>
                         <p className="text-slate-600 mt-4 max-w-xl mx-auto">
                           مساهمتك، مهما كانت بسيطة، تحدث فرقًا كبيرًا في مجتمعنا العلمي. ابدأ الآن واكسب أولى نقاطك.
                         </p>
                         <button className="mt-8 bg-primary-600 text-white font-bold py-4 px-10 rounded-full hover:bg-primary-700 transition-transform transform hover:scale-105 text-lg shadow-lg shadow-primary-200">
                            ابدأ المساهمة الآن
                         </button>
                    </div>
                </section>
            </main>
            <Footer />
        </div>
    );
};

export default RewardsPage;
