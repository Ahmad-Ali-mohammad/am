
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const partners = [
    { name: 'جامعة الملك سعود', logoUrl: 'https://picsum.photos/seed/ksu/200/100', description: 'منارة العلم والمعرفة في المملكة، تقدم برامج أكاديمية متنوعة بالتعاون مع المنصة.' },
    { name: 'جامعة القاهرة', logoUrl: 'https://picsum.photos/seed/cairo/200/100', description: 'صرح تعليمي عريق يشارك خبراته البحثية والأكاديمية عبر دورات متخصصة.' },
    { name: 'الجامعة الأمريكية في بيروت', logoUrl: 'https://picsum.photos/seed/aub/200/100', description: 'تساهم في إثراء المحتوى التعليمي بمعايير عالمية في مجالات الهندسة والطب.' },
    { name: 'معهد ماساتشوستس للتكنولوجيا (عربي)', logoUrl: 'https://picsum.photos/seed/mit/200/100', description: 'شراكة استراتيجية لتقديم محتوى تقني وهندسي متقدم باللغة العربية.' },
];

const InstitutesPage: React.FC = () => {
    return (
        <div className="bg-gray-50">
            <Header />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                 <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">
                        شركاؤنا الأكاديميون
                    </h1>
                    <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                        نفخر بالتعاون مع أعرق الجامعات والمعاهد البحثية لتقديم محتوى تعليمي لا يضاهى.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {partners.map((partner, index) => (
                        <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col sm:flex-row items-center p-6 transition-transform transform hover:scale-105 hover:shadow-xl">
                           <div className="flex-shrink-0 mb-4 sm:mb-0 sm:ml-6">
                             <img src={partner.logoUrl} alt={`${partner.name} Logo`} className="h-20 object-contain"/>
                           </div>
                           <div className="text-center sm:text-right">
                               <h2 className="text-2xl font-bold text-gray-800">{partner.name}</h2>
                               <p className="mt-2 text-gray-600">{partner.description}</p>
                               <button className="mt-4 text-primary-600 font-semibold hover:underline">
                                 عرض الدورات المقدمة
                               </button>
                           </div>
                        </div>
                    ))}
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default InstitutesPage;
