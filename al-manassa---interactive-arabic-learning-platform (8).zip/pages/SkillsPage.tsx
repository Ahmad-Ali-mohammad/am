
import React, { useState, useMemo } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SkillCard from '../components/SkillCard';
import { MOCK_SKILL_COURSES } from '../constants';
import { SkillCourse } from '../types';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { BriefcaseIcon } from '../components/icons/BriefcaseIcon';

const SkillsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = useMemo(() => ['All', ...Array.from(new Set(MOCK_SKILL_COURSES.map(s => s.category)))], []);

  const filteredSkills = useMemo(() => 
      MOCK_SKILL_COURSES.filter(skill => selectedCategory === 'All' || skill.category === selectedCategory)
  , [selectedCategory]);

  return (
    <div className="bg-slate-50 min-h-screen" dir="rtl">
      <Header />
      
      {/* Dynamic Header Section */}
      <section className="bg-slate-900 text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-primary-600 skew-x-12 translate-x-20 opacity-20"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-primary-500/20 text-primary-400 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest mb-6">
                <SparklesIcon className="w-4 h-4" />
                تطوير المهارات العملية
            </div>
            <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
              تعلم مهنة العصر <br/>
              <span className="text-primary-400 underline decoration-primary-500/30">واصنع دخلك الخاص</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              مسارات مهنية مكثفة صُممت لتنقلك من الهواية إلى الاحتراف في مجالات تقنية وإبداعية مطلوبة في سوق العمل الحر والشركات.
            </p>
          </div>
        </div>
      </section>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Category Navigation */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
            <div className="flex items-center gap-3">
                <div className="bg-white p-3 rounded-2xl shadow-sm">
                    <BriefcaseIcon className="w-6 h-6 text-primary-600" />
                </div>
                <div>
                    <h2 className="text-xl font-bold text-slate-800">التصنيفات المهنية</h2>
                    <p className="text-sm text-slate-500">اختر المجال الذي يناسب اهتماماتك</p>
                </div>
            </div>
            
            <div className="flex bg-white p-1.5 rounded-2xl shadow-sm border border-slate-100 overflow-x-auto no-scrollbar max-w-full">
                {categories.map(category => (
                    <button 
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`px-6 py-2 text-sm font-bold rounded-xl transition-all whitespace-nowrap ${
                            selectedCategory === category
                            ? 'bg-primary-600 text-white shadow-md shadow-primary-200'
                            : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                        }`}
                    >
                        {category === 'All' ? 'كل المهارات' : category}
                    </button>
                ))}
            </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-20">
            {filteredSkills.map(skill => (
                <SkillCard key={skill.id} skill={skill} />
            ))}
        </div>

        {/* Career Path Call to Action */}
        <section className="bg-gradient-to-r from-primary-600 to-indigo-700 rounded-[2.5rem] p-8 md:p-16 text-white text-center shadow-2xl shadow-primary-900/20">
            <h3 className="text-3xl md:text-4xl font-black mb-6">هل تبحث عن توجيه مهني مخصص؟</h3>
            <p className="text-lg text-primary-100 mb-10 max-w-2xl mx-auto leading-relaxed">
              لدينا خبراء جاهزون لمساعدتك في رسم مسارك الوظيفي وتحديد المهارات التي تنقصك للوصول إلى هدفك.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
                <button className="bg-white text-primary-700 font-black px-10 py-4 rounded-2xl hover:bg-slate-100 transition-all shadow-xl">
                    تحدث مع مستشار مهني
                </button>
                <button className="bg-primary-500/30 backdrop-blur-md border border-white/20 text-white font-black px-10 py-4 rounded-2xl hover:bg-white/10 transition-all">
                    عرض قصص النجاح
                </button>
            </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default SkillsPage;
