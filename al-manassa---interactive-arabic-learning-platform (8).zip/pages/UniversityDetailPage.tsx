
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseCard from '../components/CourseCard';
import { MOCK_SYRIAN_UNIVERSITIES, MOCK_COURSES } from '../constants';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { AcademicCapIcon } from '../components/icons/AcademicCapIcon';
import { ChartPieIcon } from '../components/icons/ChartPieIcon';
import { ChevronDownIcon } from '../components/icons/ChevronDownIcon';
import { BookOpenIcon } from '../components/icons/BookOpenIcon';
import { BuildingLibraryIcon } from '../components/icons/BuildingLibraryIcon';
import { NewspaperIcon } from '../components/icons/NewspaperIcon';
import { MapPinIcon } from '../components/icons/MapPinIcon';
import { UserCircleIcon } from '../components/icons/UserCircleIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';

const UniversityDetailPage: React.FC = () => {
    const { uniId } = useParams<{ uniId: string }>();
    const uni = MOCK_SYRIAN_UNIVERSITIES.find(u => u.id === uniId);
    const [activeTab, setActiveTab] = useState<'overview' | 'colleges' | 'resources' | 'students' | 'contact'>('overview');
    const [openCollege, setOpenCollege] = useState<string | null>(null);

    // Filter courses relevant to this university (simulated)
    const universityCourses = MOCK_COURSES.filter(course => 
        course.curriculum === 'syrian' && course.id === 'c1'
    );

    if (!uni) return <div className="text-center py-20 font-bold">لم يتم العثور على الجامعة.</div>;

    const tabs = [
        { id: 'overview', label: 'نظرة عامة', icon: <AcademicCapIcon className="w-4 h-4 ml-1" /> },
        { id: 'colleges', label: 'الكليات والأقسام', icon: <BuildingLibraryIcon className="w-4 h-4 ml-1" /> },
        { id: 'resources', label: 'الموارد الأكاديمية', icon: <BookOpenIcon className="w-4 h-4 ml-1" /> },
        { id: 'students', label: 'خدمات الطلاب', icon: <UserGroupIcon className="w-4 h-4 ml-1" /> },
        { id: 'contact', label: 'الموقع والاتصال', icon: <MapPinIcon className="w-4 h-4 ml-1" /> }
    ];

    return (
        <div className="bg-slate-50 min-h-screen" dir="rtl">
            <Header />
            
            {/* Hero & Image Gallery */}
            <div className="bg-white border-b overflow-hidden">
                <div className="relative h-96 group">
                     {/* Simulating Image Gallery with first campus image or fallback */}
                    <img 
                        src={uni.campusImages[0] || 'https://images.unsplash.com/photo-1541339907198-e08756defeec?q=80&w=1000&h=600&auto=format&fit=crop'} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                        alt="Campus"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/20 to-transparent"></div>
                    <div className="absolute bottom-0 right-0 left-0 p-8 container mx-auto flex flex-col md:flex-row items-center gap-8 text-white">
                        <div className="w-32 h-32 bg-white/10 backdrop-blur-md rounded-3xl p-4 flex items-center justify-center border border-white/20">
                            <img src={uni.logoUrl} alt={uni.name} className="max-h-full max-w-full object-contain filter brightness-0 invert" />
                        </div>
                        <div className="text-center md:text-right flex-1">
                            <h1 className="text-4xl md:text-5xl font-black mb-2">{uni.name}</h1>
                            <div className="flex flex-wrap gap-4 justify-center md:justify-start opacity-90">
                                <span className="flex items-center text-sm font-bold bg-white/20 px-4 py-1.5 rounded-full backdrop-blur-sm">
                                    <MapPinIcon className="w-4 h-4 ml-1" /> {uni.location}
                                </span>
                                <span className="flex items-center text-sm font-bold bg-white/20 px-4 py-1.5 rounded-full backdrop-blur-sm">
                                    تأسست عام {uni.foundationYear}
                                </span>
                                <span className="flex items-center text-sm font-bold bg-yellow-400 text-slate-900 px-4 py-1.5 rounded-full shadow-lg">
                                    المرتبة #{uni.ranking} محلياً
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Navigation Tabs */}
            <div className="sticky top-16 bg-white shadow-sm z-30 border-b">
                <div className="container mx-auto px-4 overflow-x-auto no-scrollbar">
                    <div className="flex gap-8 min-w-max">
                        {tabs.map(tab => (
                            <button 
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as any)}
                                className={`py-5 font-bold text-sm border-b-4 transition-all flex items-center ${activeTab === tab.id ? 'border-primary-600 text-primary-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                            >
                                {tab.icon}
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <main className="container mx-auto px-4 py-12">
                {activeTab === 'overview' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 animate-fade-in">
                        <div className="lg:col-span-2 space-y-10">
                            <section className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
                                <h2 className="text-2xl font-black mb-6 text-slate-800 border-r-4 border-primary-600 pr-4">عن الجامعة وتاريخها</h2>
                                <p className="text-slate-600 leading-relaxed text-lg mb-6">{uni.description}</p>
                                <div className="bg-slate-50 p-6 rounded-2xl italic text-slate-500 border-r-2 border-slate-200 text-sm">
                                    {uni.history}
                                </div>
                            </section>

                            <section className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
                                <h2 className="text-2xl font-black mb-6 text-slate-800 border-r-4 border-green-600 pr-4">الإنجازات والجوائز</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {uni.achievements.map((ach, i) => (
                                        <div key={i} className="flex items-start gap-3 p-4 bg-green-50/50 rounded-2xl text-green-800">
                                            <SparklesIcon className="w-6 h-6 flex-shrink-0" />
                                            <p className="font-bold text-sm">{ach}</p>
                                        </div>
                                    ))}
                                </div>
                            </section>

                            <section className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
                                <h2 className="text-2xl font-black mb-6 text-slate-800 border-r-4 border-blue-600 pr-4">الشراكات الدولية</h2>
                                <div className="flex flex-wrap gap-4">
                                    {uni.partnerships.map((p, i) => (
                                        <span key={i} className="bg-blue-100 text-blue-800 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-wide">
                                            {p}
                                        </span>
                                    ))}
                                </div>
                            </section>
                        </div>
                        
                        <div className="space-y-8">
                             <div className="bg-slate-900 text-white p-8 rounded-[2rem] shadow-2xl relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500 rounded-full -translate-y-16 translate-x-16 opacity-20 group-hover:scale-150 transition-transform duration-700"></div>
                                <h3 className="text-xl font-black mb-6">إحصائيات سريعة</h3>
                                <div className="space-y-6">
                                    <div className="flex justify-between items-center">
                                        <span className="text-slate-400 text-sm">إجمالي الطلاب</span>
                                        <span className="text-2xl font-black">{uni.studentCount.toLocaleString('ar-EG')}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-t border-white/10 pt-4">
                                        <span className="text-slate-400 text-sm">الهيئة التدريسية</span>
                                        <span className="text-2xl font-black">{uni.facultyCount.toLocaleString('ar-EG')}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-t border-white/10 pt-4">
                                        <span className="text-slate-400 text-sm">عدد الكليات</span>
                                        <span className="text-2xl font-black">{uni.collegeCount}</span>
                                    </div>
                                </div>
                                <button className="w-full mt-8 bg-primary-600 py-4 rounded-2xl font-black hover:bg-primary-700 transition-all shadow-lg shadow-primary-900/40">طلب دليل الجامعة (PDF)</button>
                            </div>

                            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
                                <h3 className="text-lg font-black mb-4">التوزع الطلابي</h3>
                                <div className="h-4 bg-slate-100 rounded-full overflow-hidden flex">
                                    <div className="w-[40%] bg-blue-500" title="هندسة"></div>
                                    <div className="w-[30%] bg-green-500" title="طب"></div>
                                    <div className="w-[20%] bg-yellow-500" title="حقوق"></div>
                                    <div className="w-[10%] bg-red-500" title="أخرى"></div>
                                </div>
                                <div className="mt-4 grid grid-cols-2 gap-2">
                                    <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500"><span className="w-2 h-2 bg-blue-500 rounded-full"></span> هندسة</div>
                                    <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500"><span className="w-2 h-2 bg-green-500 rounded-full"></span> طب</div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'colleges' && (
                    <div className="space-y-6 max-w-5xl mx-auto animate-fade-in">
                        <div className="flex justify-between items-center mb-8">
                            <h2 className="text-3xl font-black text-slate-800">الهيكل التنظيمي للكليات</h2>
                            <span className="bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-xs font-black">{uni.colleges.length} كلية متاحة</span>
                        </div>
                        {uni.colleges.map(college => (
                            <div key={college.id} className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden transition-all hover:shadow-xl group">
                                <button 
                                    onClick={() => setOpenCollege(openCollege === college.id ? null : college.id)}
                                    className="w-full flex flex-col md:flex-row items-center justify-between p-8 hover:bg-slate-50/50 transition-colors"
                                >
                                    <div className="flex items-center gap-6">
                                        <div className="bg-primary-600 p-4 rounded-3xl shadow-lg shadow-primary-200 text-white group-hover:rotate-6 transition-transform">
                                            <BuildingLibraryIcon className="w-8 h-8" />
                                        </div>
                                        <div className="text-right">
                                            <h3 className="text-2xl font-black text-slate-800 mb-1">{college.name}</h3>
                                            <p className="text-sm text-slate-400 font-bold flex items-center">
                                                <UserCircleIcon className="w-4 h-4 ml-1" /> عميد الكلية: {college.dean}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-8 mt-4 md:mt-0">
                                        <div className="text-center">
                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">الأقسام</p>
                                            <p className="text-xl font-black text-slate-800">{college.departments.length}</p>
                                        </div>
                                        <ChevronDownIcon className={`w-6 h-6 text-slate-400 transition-transform duration-500 ${openCollege === college.id ? 'rotate-180 text-primary-600' : ''}`} />
                                    </div>
                                </button>
                                {openCollege === college.id && (
                                    <div className="p-8 border-t bg-slate-50/30 grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-down">
                                        <div className="lg:col-span-1 space-y-6">
                                            <div>
                                                <p className="text-xs font-black text-primary-600 mb-2 uppercase tracking-widest">الرؤية والرسالة</p>
                                                <p className="text-slate-600 text-sm italic leading-relaxed">{college.vision}</p>
                                            </div>
                                            <div className="p-4 bg-white rounded-2xl border border-slate-100">
                                                <p className="text-xs font-black text-slate-400 mb-2">إحصائيات الخريجين</p>
                                                <p className="text-slate-700 text-sm font-bold">{college.graduationStats}</p>
                                            </div>
                                        </div>
                                        <div className="lg:col-span-2">
                                            <p className="text-xs font-black text-slate-400 mb-4 uppercase tracking-widest">الأقسام والدرجات العلمية</p>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                                {college.departments.map(dep => (
                                                    <div key={dep.id} className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-primary-300 transition-all shadow-sm">
                                                        <p className="font-black text-slate-900 mb-3">{dep.name}</p>
                                                        <div className="flex flex-wrap gap-1.5 mb-4">
                                                            {dep.degrees.map(d => <span key={d} className="bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg text-[10px] font-black">{d}</span>)}
                                                        </div>
                                                        <div className="flex justify-between items-center pt-3 border-t text-[10px]">
                                                            <button className="text-primary-600 font-black hover:underline decoration-2">خطة الدراسة (v2024)</button>
                                                            <span className="text-slate-400">متطلبات: {dep.admissionRequirements.slice(0, 15)}...</span>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'resources' && (
                    <div className="space-y-12 animate-fade-in">
                        <section>
                            <h2 className="text-2xl font-black text-slate-800 mb-8 flex items-center">
                                <BuildingLibraryIcon className="w-8 h-8 ml-3 text-primary-600" />
                                المكتبة الرقمية والمنشورات
                            </h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {[
                                    { title: 'دليل الأبحاث الجامعية', type: 'مجلة علمية', author: 'جامعة دمشق' },
                                    { title: 'أرشيف المخطوطات', type: 'كتاب تاريخي', author: 'قسم التاريخ' },
                                    { title: 'مجلة الطب العربي', type: 'مجلة محكمة', author: 'كلية الطب' },
                                    { title: 'التحول الرقمي 2024', type: 'ورقة بحثية', author: 'مركز المعلوماتية' }
                                ].map((res, i) => (
                                    <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-lg transition-all group">
                                        <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-primary-50 transition-colors">
                                            <NewspaperIcon className="w-6 h-6 text-slate-400 group-hover:text-primary-600" />
                                        </div>
                                        <h4 className="font-black text-slate-800 mb-1 group-hover:text-primary-600">{res.title}</h4>
                                        <p className="text-[10px] text-slate-400 font-bold mb-4 uppercase">{res.type} • {res.author}</p>
                                        <button className="text-primary-600 text-[10px] font-black border-b-2 border-primary-100 hover:border-primary-600">تحميل المورد</button>
                                    </div>
                                ))}
                            </div>
                        </section>

                        <section>
                            <h2 className="text-2xl font-black text-slate-800 mb-8 flex items-center">
                                <SparklesIcon className="w-8 h-8 ml-3 text-yellow-500" />
                                محاضرات متميزة (أونلاين)
                            </h2>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                {universityCourses.map(course => <CourseCard key={course.id} course={course} />)}
                            </div>
                        </section>
                    </div>
                )}

                {activeTab === 'students' && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-fade-in">
                        <section className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100">
                            <h2 className="text-2xl font-black text-slate-800 mb-8 border-r-4 border-purple-600 pr-4">المنح الدراسية والتمويل</h2>
                            <div className="space-y-4">
                                {uni.scholarships.map((s, i) => (
                                    <div key={i} className="p-6 bg-purple-50 rounded-3xl border border-purple-100 flex justify-between items-center group cursor-pointer hover:bg-purple-100 transition-colors">
                                        <span className="font-black text-purple-900">{s}</span>
                                        <span className="text-[10px] bg-white text-purple-600 px-3 py-1 rounded-full font-black shadow-sm group-hover:scale-110 transition-transform">تقديم الآن</span>
                                    </div>
                                ))}
                            </div>
                        </section>

                        <section className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100">
                            <h2 className="text-2xl font-black text-slate-800 mb-8 border-r-4 border-orange-600 pr-4">الأندية والأنشطة الطلابية</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {uni.studentClubs.map((club, i) => (
                                    <div key={i} className="flex items-center gap-4 p-4 border border-slate-100 rounded-3xl hover:bg-orange-50 transition-all hover:translate-x-1">
                                        <div className="w-10 h-10 bg-orange-100 rounded-2xl flex items-center justify-center">
                                            <UserGroupIcon className="w-5 h-5 text-orange-600" />
                                        </div>
                                        <p className="font-black text-slate-700 text-sm">{club}</p>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-8 p-6 bg-slate-900 rounded-3xl text-white text-center">
                                <p className="text-xs text-slate-400 mb-2 font-bold uppercase tracking-widest">هل تملك موهبة؟</p>
                                <h4 className="text-lg font-black mb-4">انضم إلى برنامج التميز الإبداعي</h4>
                                <button className="bg-orange-500 px-8 py-2.5 rounded-2xl font-black text-sm hover:bg-orange-600 shadow-xl shadow-orange-900/40">سجل الآن</button>
                            </div>
                        </section>
                    </div>
                )}

                {activeTab === 'contact' && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-fade-in">
                        <div className="space-y-6">
                            <h2 className="text-3xl font-black text-slate-800">معلومات الاتصال الرسمي</h2>
                            <div className="space-y-4">
                                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-6 group hover:border-primary-500 transition-colors">
                                    <div className="w-14 h-14 bg-primary-100 rounded-2xl flex items-center justify-center">
                                        <MapPinIcon className="w-6 h-6 text-primary-600" />
                                    </div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 font-black uppercase">العنوان الفعلي</p>
                                        <p className="text-lg font-black text-slate-800">{uni.address}</p>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-6 group hover:border-primary-500 transition-colors">
                                    <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center">
                                        <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 font-black uppercase">الهاتف الرئيسي</p>
                                        <p className="text-lg font-black text-slate-800">{uni.phone}</p>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-6 group hover:border-primary-500 transition-colors">
                                    <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center">
                                        <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 font-black uppercase">البريد الإلكتروني</p>
                                        <p className="text-lg font-black text-slate-800">{uni.email}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="h-[500px] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white bg-slate-200 relative">
                             {/* Simulated interactive map */}
                             <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/damascusmap/800/600')] bg-cover opacity-50"></div>
                             <div className="absolute inset-0 bg-primary-600/10"></div>
                             <div className="absolute inset-0 flex items-center justify-center">
                                <div className="bg-white p-6 rounded-3xl shadow-2xl text-center max-w-xs animate-bounce">
                                    <MapPinIcon className="w-12 h-12 text-primary-600 mx-auto mb-2" />
                                    <p className="font-black text-slate-800">{uni.name}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase">{uni.location}</p>
                                </div>
                             </div>
                             <div className="absolute bottom-6 right-6 left-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl flex justify-between items-center border border-white">
                                <span className="text-xs font-black text-slate-700">فتح في خرائط جوجل</span>
                                <button className="bg-primary-600 text-white p-2 rounded-xl"><MapPinIcon className="w-5 h-5" /></button>
                             </div>
                        </div>
                    </div>
                )}
            </main>

            <style dangerouslySetInnerHTML={{ __html: `
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                @keyframes slide-down {
                    from { opacity: 0; max-height: 0; }
                    to { opacity: 1; max-height: 2000px; }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
                .animate-slide-down {
                    animation: slide-down 0.5s ease-out forwards;
                }
                .no-scrollbar::-webkit-scrollbar {
                    display: none;
                }
                .no-scrollbar {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
            `}} />
            <Footer />
        </div>
    );
};

export default UniversityDetailPage;
