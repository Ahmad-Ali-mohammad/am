
import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { ChevronDownIcon } from '../components/icons/ChevronDownIcon';

const faqData = [
    {
        question: 'كيف يمكنني التسجيل في دورة جديدة؟',
        answer: 'يمكنك تصفح قائمة الدورات من صفحة "الدورات". عند العثور على دورة تهمك، انقر عليها لعرض التفاصيل ثم اضغط على زر "التسجيل في الدورة" واتبع التعليمات لإتمام عملية الدفع والتسجيل.'
    },
    {
        question: 'هل يمكنني الحصول على شهادة بعد إتمام الدورة؟',
        answer: 'نعم، بعد إكمال جميع متطلبات الدورة بنجاح، بما في ذلك الدروس والواجبات، ستتمكن من إصدار شهادة إتمام إلكترونية يمكنك طباعتها أو مشاركتها.'
    },
    {
        question: 'ما هي طرق الدفع المتاحة؟',
        answer: 'نحن نقبل الدفع عبر البطاقات الائتمانية (فيزا وماستركارد)، باي بال، والتحويلات البنكية. جميع المعاملات آمنة ومشفرة بالكامل.'
    },
    {
        question: 'هل يمكنني الوصول إلى محتوى الدورة بعد انتهائها؟',
        answer: 'نعم، بمجرد التسجيل في دورة، ستحصل على وصول مدى الحياة لمحتواها. يمكنك العودة إلى الدروس والمواد في أي وقت تريده.'
    },
    {
        question: 'كيف يمكنني التواصل مع المدرب؟',
        answer: 'توفر كل دورة قسمًا خاصًا للنقاشات والأسئلة حيث يمكنك طرح أسئلتك مباشرة على المدرب أو التفاعل مع الطلاب الآخرين. بعض الدورات تقدم أيضًا جلسات مباشرة عبر الفيديو.'
    }
];

const FAQPage: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const toggleFAQ = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    const filteredFaqs = faqData.filter(faq => 
        faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="bg-gray-50 min-h-screen">
            <Header />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">الأسئلة الشائعة</h1>
                    <p className="mt-4 text-lg text-gray-600">هل لديك سؤال؟ ابحث عن إجابتك هنا.</p>
                </div>
                
                <div className="mt-12 max-w-3xl mx-auto">
                    <div className="mb-8">
                        <input
                            type="text"
                            placeholder="ابحث في الأسئلة..."
                            className="w-full px-5 py-3 border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="space-y-4">
                        {filteredFaqs.map((faq, index) => (
                            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                                <button
                                    onClick={() => toggleFAQ(index)}
                                    className="w-full flex justify-between items-center p-6 text-right focus:outline-none"
                                >
                                    <span className="text-lg font-semibold text-gray-800">{faq.question}</span>
                                    <ChevronDownIcon className={`w-6 h-6 text-gray-500 transition-transform ${openIndex === index ? 'rotate-180' : ''}`} />
                                </button>
                                {openIndex === index && (
                                    <div className="px-6 pb-6">
                                        <p className="text-gray-600">{faq.answer}</p>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                     {filteredFaqs.length === 0 && (
                        <div className="text-center bg-white p-8 rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold text-gray-700">لم يتم العثور على نتائج</h3>
                            <p className="text-gray-500 mt-2">حاول استخدام كلمات بحث مختلفة.</p>
                        </div>
                    )}
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default FAQPage;
