
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';
import { useNavigate, Link } from 'react-router-dom';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';
import { ArrowRightIcon } from '../components/icons/ArrowRightIcon';

const LoginPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const { login } = useAuth();
  const navigate = useNavigate();

  const [signInEmail, setSignInEmail] = useState('demo@example.com');
  const [signInPassword, setSignInPassword] = useState('password');
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.STUDENT);

  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpRole, setSignUpRole] = useState<UserRole>(UserRole.STUDENT);
  const [signupSuccess, setSignupSuccess] = useState(false);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    login(selectedRole);
    
    // Redirect to 2FA for privileged roles, otherwise go to dashboard
    if (selectedRole === UserRole.INSTRUCTOR || selectedRole === UserRole.ADMIN || selectedRole === UserRole.CONTENT_MANAGER) {
        navigate('/2fa');
    } else {
        navigate('/dashboard');
    }
  };
  
  const handleSignUp = (e: React.FormEvent) => {
      e.preventDefault();
      // Mock signup and show success message for the review process
      console.log(`Mock signup for ${signUpName} as ${signUpRole}.`);
      setSignupSuccess(true);
  }


  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
        {/* Back to Home Button */}
        <div className="absolute top-6 right-6 sm:top-8 sm:right-8">
            <Link 
                to="/" 
                className="flex items-center text-sm font-bold text-gray-600 hover:text-primary-600 transition-all bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md group"
            >
                <ArrowRightIcon className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                العودة للرئيسية
            </Link>
        </div>

        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
            <Link to="/" className="text-4xl font-extrabold text-gray-900 hover:text-primary-600 transition-colors">
                المنصّة
            </Link>
            <h2 className="mt-6 text-center text-3xl font-bold text-gray-800">
                {activeTab === 'signin' ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب جديد'}
            </h2>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
            <div className="bg-white py-8 px-4 shadow-lg sm:rounded-lg sm:px-10">
                <div className="mb-6">
                    <div className="flex border-b border-gray-200">
                        <button
                            onClick={() => { setActiveTab('signin'); setSignupSuccess(false); }}
                            className={`w-1/2 py-4 text-center font-medium text-sm focus:outline-none ${activeTab === 'signin' ? 'border-b-2 border-primary-600 text-primary-600' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            تسجيل الدخول
                        </button>
                        <button
                            onClick={() => { setActiveTab('signup'); setSignupSuccess(false); }}
                            className={`w-1/2 py-4 text-center font-medium text-sm focus:outline-none ${activeTab === 'signup' ? 'border-b-2 border-primary-600 text-primary-600' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            إنشاء حساب
                        </button>
                    </div>
                </div>
                
                {activeTab === 'signin' ? (
                    <form className="space-y-6" onSubmit={handleSignIn}>
                        <div>
                            <label htmlFor="email-signin" className="block text-sm font-medium text-gray-700">البريد الإلكتروني (تجريبي)</label>
                            <input id="email-signin" type="email" value={signInEmail} onChange={e => setSignInEmail(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm" disabled />
                        </div>
                        <div>
                            <label htmlFor="password-signin" className="block text-sm font-medium text-gray-700">كلمة المرور (تجريبية)</label>
                            <input id="password-signin" type="password" value={signInPassword} onChange={e => setSignInPassword(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm" disabled/>
                        </div>
                         <div>
                            <label htmlFor="role-signin" className="block text-sm font-medium text-gray-700">اختر دورًا للدخول به</label>
                            <select id="role-signin" value={selectedRole} onChange={(e) => setSelectedRole(e.target.value as UserRole)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
                                <option value={UserRole.STUDENT}>طالب</option>
                                <option value={UserRole.INSTRUCTOR}>مدرب</option>
                                <option value={UserRole.CONTENT_MANAGER}>مدير محتوى</option>
                                <option value={UserRole.ADMIN}>مسؤول</option>
                            </select>
                        </div>
                        <div className="flex items-center justify-between">
                            <div className="text-sm">
                                <Link to="/forgot-password" className="font-medium text-primary-600 hover:text-primary-500">
                                    هل نسيت كلمة المرور؟
                                </Link>
                            </div>
                        </div>
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                                تسجيل الدخول
                            </button>
                        </div>
                    </form>
                ) : signupSuccess ? (
                    <div className="text-center">
                        <CheckCircleIcon className="w-16 h-16 text-success-500 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-gray-800">تم إرسال طلبك بنجاح</h3>
                        <p className="text-gray-600 mt-2">
                            سيقوم فريقنا بمراجعة طلبك. ستتلقى بريدًا إلكترونيًا عند الموافقة على حسابك.
                        </p>
                        <button onClick={() => setActiveTab('signin')} className="mt-6 w-full text-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700">
                            العودة لتسجيل الدخول
                        </button>
                    </div>
                ) : (
                    <form className="space-y-6" onSubmit={handleSignUp}>
                         <div>
                            <label htmlFor="name-signup" className="block text-sm font-medium text-gray-700">الاسم الكامل</label>
                            <input id="name-signup" type="text" value={signUpName} onChange={e => setSignUpName(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                        </div>
                        <div>
                            <label htmlFor="email-signup" className="block text-sm font-medium text-gray-700">البريد الإلكتروني</label>
                            <input id="email-signup" type="email" value={signUpEmail} onChange={e => setSignUpEmail(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                        </div>
                        <div>
                            <label htmlFor="password-signup" className="block text-sm font-medium text-gray-700">كلمة المرور</label>
                            <input id="password-signup" type="password" value={signUpPassword} onChange={e => setSignUpPassword(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                        </div>
                         <div>
                            <label htmlFor="role-signup" className="block text-sm font-medium text-gray-700">أرغب في التسجيل كـ</label>
                            <select id="role-signup" value={signUpRole} onChange={(e) => setSignUpRole(e.target.value as UserRole)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
                                <option value={UserRole.STUDENT}>طالب</option>
                                <option value={UserRole.INSTRUCTOR}>مدرب</option>
                            </select>
                        </div>
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                                إنشاء حساب
                            </button>
                        </div>
                    </form>
                )}
            </div>
        </div>
    </div>
  );
};

export default LoginPage;
