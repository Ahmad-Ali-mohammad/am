
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { MOCK_SYRIAN_UNIVERSITIES, MOCK_SPECIALIZATIONS } from '../constants';
import { SyrianUniversity, SpecializationGuide } from '../types';
import { MagnifyingGlassIcon } from '../components/icons/MagnifyingGlassIcon';
import { MapIcon } from '../components/icons/MapIcon';
import { AcademicCapIcon } from '../components/icons/AcademicCapIcon';
import { ChartBarIcon } from '../components/icons/ChartBarIcon';

const UniversityCard: React.FC<{ uni: SyrianUniversity }> = ({ uni }) => (
    <Link to={`/university/${uni.id}`} className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group">
        <div className="relative h-48 bg-slate-100 flex items-center justify-center p-8">
            <img src={uni.logoUrl} alt={uni.name} className="max-h-full max-w-full object-contain transform group-hover:scale-110 transition-transform" />
            <div className="absolute top-4 right-4">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${uni.type === 'public' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                    {uni.type === 'public' ? 'حكومية' : 'خاصة'}
                </span>
            </div>
        </div>
        <div className="p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-2">{uni.name}</h3>
            <div className="flex items-center text-sm text-gray-500 mb-4">
                <MapIcon className="w-4 h-4 ml-1" />
                <span>{uni.location}</span>
                <span className="mx-2">•</span>
                <span>تأسست {uni.foundationYear}</span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center border-t pt-4">
                <div>
                    <p className="text-xs text-gray-400">الكليات</p>
                    <p className="font-bold text-primary-600">{uni.collegeCount}</p>
                </div>
                <div>
                    <p className="text-xs text-gray-400">التصنيف</p>
                    <p className="font-bold text-yellow-600">#{uni.ranking}</p>
                </div>
            </div>
        </div>
    </Link>
);

const SyrianUniversitiesPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [activeType, setActiveType] = useState<'all' | 'public' | 'private'>('all');
    const [view, setView] = useState<'unis' | 'specializations'>('unis');

    const filteredUnis = useMemo(() => {
        return MOCK_SYRIAN_UNIVERSITIES.filter(uni => {
            const matchesSearch = uni.name.includes(searchTerm) || uni.location.includes(searchTerm);
            const matchesType = activeType === 'all' || uni.type === activeType;
            return matchesSearch && matchesType;
        });
    }, [searchTerm, activeType]);

    return (
        <div className="bg-slate-50 min-h-screen" dir="rtl">
            <Header />
            <main className="container mx-auto px-4 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4">دليل التعليم الجامعي في سوريا</h1>
                    <p className="text-lg text-slate-600 max-w-2xl mx-auto">نظام شامل لاستكشاف الجامعات، الكليات، والتخصصات الأكاديمية المعتمدة.</p>
                </div>

                {/* Main Navigation & Search */}
                <div className="bg-white p-4 rounded-2xl shadow-sm mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
                    <div className="flex bg-slate-100 p-1 rounded-xl">
                        <button onClick={() => setView('unis')} className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${view === 'unis' ? 'bg-white text-primary-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>الجامعات</button>
                        <button onClick={() => setView('specializations')} className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${view === 'specializations' ? 'bg-white text-primary-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>التخصصات</button>
                    </div>

                    <div className="relative flex-1 max-w-md w-full">
                        <input 
                            type="text" 
                            placeholder="ابحث عن جامعة أو مدينة أو تخصص..." 
                            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    </div>

                    {view === 'unis' && (
                        <div className="flex gap-2">
                            <button onClick={() => setActiveType('all')} className={`px-4 py-2 rounded-xl text-xs font-bold ${activeType === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600'}`}>الكل</button>
                            <button onClick={() => setActiveType('public')} className={`px-4 py-2 rounded-xl text-xs font-bold ${activeType === 'public' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>حكومية</button>
                            <button onClick={() => setActiveType('private')} className={`px-4 py-2 rounded-xl text-xs font-bold ${activeType === 'private' ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-600'}`}>خاصة</button>
                        </div>
                    )}
                </div>

                {view === 'unis' ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredUnis.map(uni => <UniversityCard key={uni.id} uni={uni} />)}
                        {filteredUnis.length === 0 && (
                            <div className="col-span-full py-20 text-center">
                                <AcademicCapIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                                <p className="text-slate-500 font-bold">لم يتم العثور على نتائج تطابق بحثك.</p>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {MOCK_SPECIALIZATIONS.map(spec => (
                            <div key={spec.id} className="bg-white p-6 rounded-2xl shadow-md border border-slate-100 hover:border-primary-200 transition-colors">
                                <div className="flex justify-between items-start mb-4">
                                    <h3 className="text-xl font-bold text-slate-800">{spec.name}</h3>
                                    <span className="bg-primary-50 text-primary-700 px-3 py-1 rounded-lg text-xs font-bold">{spec.category}</span>
                                </div>
                                <div className="space-y-4">
                                    <div>
                                        <p className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">مجالات العمل</p>
                                        <div className="flex flex-wrap gap-2">
                                            {spec.workFields.map(f => <span key={f} className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs">{f}</span>)}
                                        </div>
                                    </div>
                                    <div className="pt-4 border-t flex justify-between items-center">
                                        <div className="flex items-center text-sm text-slate-500">
                                            <ChartBarIcon className="w-4 h-4 ml-1" />
                                            <span>معدل الرواتب: <span className="font-bold text-slate-800">{spec.averageSalaryGrade === 'high' ? 'مرتفع' : 'متوسط'}</span></span>
                                        </div>
                                        <button className="text-primary-600 text-sm font-bold hover:underline">عرض البرامج الأكاديمية</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Interactive Map Simulation Section */}
                <section className="mt-20">
                    <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center">
                        <MapIcon className="w-6 h-6 ml-2 text-primary-500" />
                        التوزع الجغرافي للمراكز الجامعية
                    </h2>
                    <div className="bg-slate-800 rounded-3xl h-96 overflow-hidden relative shadow-2xl">
                         {/* Placeholder for real map API like Google Maps */}
                         <div className="absolute inset-0 opacity-40 bg-[url('https://picsum.photos/seed/map/1200/600')] bg-cover"></div>
                         <div className="absolute inset-0 flex items-center justify-center">
                            <div className="text-center text-white z-10 p-8">
                                <p className="text-2xl font-black mb-2 italic">الخارطة الأكاديمية لسورية</p>
                                <p className="text-slate-300">خريطة تفاعلية تعرض مواقع جميع الكليات والمعاهد الجامعية.</p>
                                <button className="mt-6 bg-white text-slate-900 px-8 py-3 rounded-full font-bold hover:bg-primary-500 hover:text-white transition-all">تفعيل الخريطة</button>
                            </div>
                         </div>
                    </div>
                </section>
            </main>
            <Footer />
        </div>
    );
};

export default SyrianUniversitiesPage;
