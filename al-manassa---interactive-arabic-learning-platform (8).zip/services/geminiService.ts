
import { GoogleGenAI, Type } from "@google/genai";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const courseIdeaSchema = {
  type: Type.OBJECT,
  properties: {
    courseTitle: {
      type: Type.STRING,
      description: "A compelling and professional title for the course.",
    },
    description: {
      type: Type.STRING,
      description: "A brief, one-paragraph description of the course, highlighting its key benefits for the learner.",
    },
    modules: {
      type: Type.ARRAY,
      description: "An array of 3-5 course modules.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "The title of the module.",
          },
          lessons: {
            type: Type.ARRAY,
            description: "An array of 3-5 lesson titles within this module.",
            items: {
              type: Type.STRING,
            },
          },
        },
        required: ["title", "lessons"],
      },
    },
  },
  required: ["courseTitle", "description", "modules"],
};

export async function generateCourseIdeas(topic: string): Promise<any> {
  try {
    const prompt = `Create a detailed course outline for a topic: "${topic}". The outline should be suitable for an online learning platform. Generate a course title, a short description, and 3-5 modules, each with 3-5 lesson titles. The language should be Arabic.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: courseIdeaSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Error generating course ideas from Gemini:", error);
    throw new Error("Failed to generate course ideas.");
  }
}
